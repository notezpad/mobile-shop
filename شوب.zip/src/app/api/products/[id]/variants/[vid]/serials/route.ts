// 📱 التحديث 34 (2026-11-06): إدارة الوحدات الفردية (IMEI/Serial) لمتغيّر منتج إلكتروني.
//
// GET  /api/products/[id]/variants/[vid]/serials
//   → قايمة كل الوحدات الفردية للمتغيّر (IMEI + بطارية + حالة).
//
// POST /api/products/[id]/variants/[vid]/serials
//   → إضافة وحدة واحدة أو قايمة IMEIs دفعة واحدة:
//     • { imei, batteryHealth?, showBattery? }   ← وحدة واحدة
//     • { imeis: ["...", "..."], batteryHealth? } ← دفعة (كل سطر = جهاز)
//
// الأمان: نفس requireAuth + requireCapability + canAccessProductBranch الموجودين.

import { NextRequest, NextResponse } from 'next/server'
import { db, withDb } from '@/lib/db'
import { requireAuth, authErrorResponse } from '@/lib/auth'
import { requireCapability, featureErrorResponse, requireModule, requireModuleWritePermission } from '@/lib/features'
import { canAccessProductBranch } from '@/lib/branch-scope-db'
import { syncProductQuantityFromVariants } from '@/lib/sync-product-quantity'

export const dynamic = 'force-dynamic'

/** تحميل الـ variant مع فحص التبعية (product → tenant → branch). */
async function loadOwned(
  tenantId: string,
  pid: number,
  vid: number,
  sessionBranchId?: number | null,
) {
  const v = await db.productVariant.findUnique({ where: { id: vid } })
  if (!v || v.productId !== pid) return null
  const p = await db.product.findUnique({ where: { id: pid } })
  if (!p || p.tenantId !== tenantId) return null
  // 🛡️ فحص الفرع — نفس نمط مت-7
  if (sessionBranchId && !(await canAccessProductBranch(tenantId, p.branchId, sessionBranchId))) {
    return null
  }
  return { variant: v, product: p }
}

// ───────────────────────────────────────────────────────────
// GET — قايمة الوحدات الفردية
// ───────────────────────────────────────────────────────────
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; vid: string }> },
) {
  let session
  try {
    session = await requireAuth()
  } catch (e) {
    const err = authErrorResponse(e)
    return NextResponse.json(err?.body, { status: err?.status })
  }
  try { await requireModule(session, 'products') } catch (e) {
    const fe = featureErrorResponse(e); if (fe) return NextResponse.json(fe.body, { status: fe.status }); throw e
  }

  const { id, vid } = await params
  const pid = parseInt(id, 10)
  const vId = parseInt(vid, 10)
  if (isNaN(pid) || isNaN(vId)) return NextResponse.json({ error: 'معرف غير صالح' }, { status: 400 })

  const owned = await loadOwned(session.tenantId, pid, vId, session.branchId)
  if (!owned) return NextResponse.json({ error: 'المتغير غير موجود' }, { status: 404 })

  const units = await db.productSerialUnit.findMany({
    where: { variantId: vId, tenantId: session.tenantId },
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      imei: true,
      batteryHealth: true,
      status: true,
      saleItemId: true,
      soldAt: true,
      createdAt: true,
    },
  })
  return NextResponse.json(units)
}

// ───────────────────────────────────────────────────────────
// POST — إضافة وحدة/وحدات جديدة
// ───────────────────────────────────────────────────────────
async function __POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; vid: string }> },
) {
  let session
  try {
    session = await requireAuth()
    await requireCapability(session, 'variants')
  } catch (e) {
    const fe = featureErrorResponse(e)
    if (fe) return NextResponse.json(fe.body, { status: fe.status })
    const err = authErrorResponse(e)
    return NextResponse.json(err?.body, { status: err?.status })
  }
  try { requireModuleWritePermission(session, 'products') } catch (e) {
    const fe = featureErrorResponse(e); if (fe) return NextResponse.json(fe.body, { status: fe.status }); throw e
  }

  const { id, vid } = await params
  const pid = parseInt(id, 10)
  const vId = parseInt(vid, 10)
  if (isNaN(pid) || isNaN(vId)) return NextResponse.json({ error: 'معرف غير صالح' }, { status: 400 })

  const owned = await loadOwned(session.tenantId, pid, vId, session.branchId)
  if (!owned) return NextResponse.json({ error: 'المتغير غير موجود' }, { status: 404 })

  if (!owned.variant.trackSerials) {
    return NextResponse.json({ error: 'هذا المتغير لا يستخدم تتبع الوحدات الفردية — فعّل trackSerials أولاً' }, { status: 400 })
  }

  const body = await req.json().catch(() => null)
  if (!body) return NextResponse.json({ error: 'بيانات غير صالحة' }, { status: 400 })

  // 📱 نسبة البطارية: رقم 0-100 أو null
  const parseBattery = (v: unknown): number | null => {
    if (v == null || v === '') return null
    const n = parseInt(String(v), 10)
    if (isNaN(n) || n < 0 || n > 100) return null
    return n
  }

  // ── وضع الدفعة: { imeis: string[] } ──
  if (Array.isArray(body.imeis)) {
    const rawImeis: string[] = body.imeis
      .map((s: unknown) => String(s ?? '').trim())
      .filter(Boolean)
    if (rawImeis.length === 0) return NextResponse.json({ error: 'لا توجد أرقام IMEI' }, { status: 400 })
    if (rawImeis.length > 200) return NextResponse.json({ error: 'الحد الأقصى 200 جهاز في الدفعة الواحدة' }, { status: 400 })

    const battery = parseBattery(body.batteryHealth)

    // 📱 فحص التكرار داخل الدفعة نفسها
    const unique = new Set(rawImeis)
    if (unique.size !== rawImeis.length) {
      return NextResponse.json({ error: 'يوجد IMEI مكرر داخل القائمة' }, { status: 400 })
    }

    // 📱 فحص التكرار مع المخزون الموجود في نفس المحل
    const existing = await db.productSerialUnit.findFirst({
      where: { tenantId: session.tenantId, imei: { in: rawImeis } },
      select: { imei: true },
    })
    if (existing) {
      return NextResponse.json({ error: `IMEI مسجّل مسبقاً: ${existing.imei}` }, { status: 400 })
    }

    const created = await db.$transaction(async (tx) => {
      const rows = await tx.productSerialUnit.createMany({
        data: rawImeis.map((imei) => ({
          variantId: vId,
          tenantId: session.tenantId,
          imei,
          batteryHealth: battery,
          status: 'in_stock',
        })),
      })
      await syncProductQuantityFromVariants(tx, pid)
      return rows
    })
    return NextResponse.json({ created: created.count }, { status: 201 })
  }

  // ── وضع الوحدة الواحدة: { imei, batteryHealth? } ──
  const imei = String(body.imei ?? '').trim()
  if (!imei) return NextResponse.json({ error: 'الـ IMEI مطلوب' }, { status: 400 })
  const battery = parseBattery(body.batteryHealth)

  // 📱 فحص التفرد
  const dup = await db.productSerialUnit.findUnique({
    where: { tenantId_imei: { tenantId: session.tenantId, imei } },
    select: { id: true },
  })
  if (dup) return NextResponse.json({ error: `IMEI مسجّل مسبقاً: ${imei}` }, { status: 400 })

  const unit = await db.$transaction(async (tx) => {
    const row = await tx.productSerialUnit.create({
      data: { variantId: vId, tenantId: session.tenantId, imei, batteryHealth: battery, status: 'in_stock' },
    })
    await syncProductQuantityFromVariants(tx, pid)
    return row
  })
  return NextResponse.json(unit, { status: 201 })
}

export async function POST(...args: Parameters<typeof __POST>) {
  return withDb(() => __POST(...args))
}
