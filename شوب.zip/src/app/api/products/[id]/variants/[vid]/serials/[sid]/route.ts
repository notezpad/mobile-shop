// 📱 التحديث 34 (2026-11-06): تعديل / حذف وحدة فردية بعينها.
//
// PATCH /api/products/[id]/variants/[vid]/serials/[sid]
//   → تعديل بيانات الوحدة (batteryHealth, status, imei).
//   ملاحظة: تعديل status إلى 'sold' يتم تلقائيًا عند البيع من نقطة البيع —
//   هنا للتصحيح اليدوي (مرتجع، تعديل إداري).
//
// DELETE /api/products/[id]/variants/[vid]/serials/[sid]
//   → حذف الوحدة (يُرفض لو مباعة بالفعل).

import { NextRequest, NextResponse } from 'next/server'
import { db, withDb } from '@/lib/db'
import { requireAuth, authErrorResponse } from '@/lib/auth'
import { requireCapability, featureErrorResponse, requireModuleWritePermission } from '@/lib/features'
import { canAccessProductBranch } from '@/lib/branch-scope-db'
import { syncProductQuantityFromVariants } from '@/lib/sync-product-quantity'

export const dynamic = 'force-dynamic'

async function loadOwnedUnit(
  tenantId: string,
  pid: number,
  vid: number,
  sid: number,
  sessionBranchId?: number | null,
) {
  const unit = await db.productSerialUnit.findUnique({ where: { id: sid } })
  if (!unit || unit.variantId !== vid || unit.tenantId !== tenantId) return null
  const p = await db.product.findUnique({ where: { id: pid } })
  if (!p || p.tenantId !== tenantId) return null
  if (sessionBranchId && !(await canAccessProductBranch(tenantId, p.branchId, sessionBranchId))) return null
  return { unit, product: p }
}

// ───────────────────────────────────────────────────────────
// PATCH — تعديل الوحدة
// ───────────────────────────────────────────────────────────
async function __PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; vid: string; sid: string }> },
) {
  let session
  try {
    session = await requireAuth()
    await requireCapability(session, 'variants')
  } catch (e) {
    const fe = featureErrorResponse(e)
    if (fe) return NextResponse.json(fe.body, { status: fe.status })
    const err = authErrorResponse(e)
    return NextResponse.json(err?.body, { status: err?.status })
  }
  try { requireModuleWritePermission(session, 'products') } catch (e) {
    const fe = featureErrorResponse(e); if (fe) return NextResponse.json(fe.body, { status: fe.status }); throw e
  }

  const { id, vid, sid } = await params
  const pid = parseInt(id, 10), vId = parseInt(vid, 10), sId = parseInt(sid, 10)
  if (isNaN(pid) || isNaN(vId) || isNaN(sId)) return NextResponse.json({ error: 'معرف غير صالح' }, { status: 400 })

  const owned = await loadOwnedUnit(session.tenantId, pid, vId, sId, session.branchId)
  if (!owned) return NextResponse.json({ error: 'الوحدة غير موجودة' }, { status: 404 })

  const body = await req.json().catch(() => ({}))
  const data: Record<string, unknown> = {}

  if (body.imei !== undefined) {
    const imei = String(body.imei ?? '').trim()
    if (!imei) return NextResponse.json({ error: 'الـ IMEI لا يمكن أن يكون فارغاً' }, { status: 400 })
    // فحص تكرار مع وحدة أخرى
    const dup = await db.productSerialUnit.findUnique({
      where: { tenantId_imei: { tenantId: session.tenantId, imei } },
      select: { id: true },
    })
    if (dup && dup.id !== sId) return NextResponse.json({ error: `IMEI مسجّل مسبقاً: ${imei}` }, { status: 400 })
    data.imei = imei
  }

  if (body.batteryHealth !== undefined) {
    if (body.batteryHealth === null || body.batteryHealth === '') {
      data.batteryHealth = null
    } else {
      const n = parseInt(String(body.batteryHealth), 10)
      if (isNaN(n) || n < 0 || n > 100) return NextResponse.json({ error: 'نسبة البطارية يجب أن تكون بين 0 و100' }, { status: 400 })
      data.batteryHealth = n
    }
  }

  if (body.status !== undefined) {
    const validStatuses = ['in_stock', 'sold', 'returned']
    if (!validStatuses.includes(body.status)) {
      return NextResponse.json({ error: 'حالة غير صالحة (in_stock / sold / returned)' }, { status: 400 })
    }
    data.status = body.status
    // 📱 لو بيرجع للمخزون (returned → in_stock) نمسح تاريخ البيع
    if (body.status === 'in_stock') {
      data.soldAt = null
      data.saleItemId = null
    }
  }

  if (Object.keys(data).length === 0) return NextResponse.json({ error: 'لا توجد حقول للتعديل' }, { status: 400 })

  const updated = await db.$transaction(async (tx) => {
    const row = await tx.productSerialUnit.update({ where: { id: sId }, data })
    // 📱 لو تغيّرت الحالة نعيد حساب كمية الـ variant
    if (data.status !== undefined) {
      await syncProductQuantityFromVariants(tx, pid)
    }
    return row
  })
  return NextResponse.json(updated)
}

// ───────────────────────────────────────────────────────────
// DELETE — حذف الوحدة (بشرط ما تكونش مباعة)
// ───────────────────────────────────────────────────────────
async function __DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; vid: string; sid: string }> },
) {
  let session
  try {
    session = await requireAuth()
    await requireCapability(session, 'variants')
  } catch (e) {
    const fe = featureErrorResponse(e)
    if (fe) return NextResponse.json(fe.body, { status: fe.status })
    const err = authErrorResponse(e)
    return NextResponse.json(err?.body, { status: err?.status })
  }

  const { id, vid, sid } = await params
  const pid = parseInt(id, 10), vId = parseInt(vid, 10), sId = parseInt(sid, 10)
  if (isNaN(pid) || isNaN(vId) || isNaN(sId)) return NextResponse.json({ error: 'معرف غير صالح' }, { status: 400 })

  const owned = await loadOwnedUnit(session.tenantId, pid, vId, sId, session.branchId)
  if (!owned) return NextResponse.json({ error: 'الوحدة غير موجودة' }, { status: 404 })

  // 📱 منع حذف الجهاز لو مباع — السجل البيعي لازم يفضل سليم
  if (owned.unit.status === 'sold') {
    return NextResponse.json({ error: 'لا يمكن حذف جهاز مباع — غيّر حالته إلى "مرتجع" أولاً' }, { status: 400 })
  }

  await db.$transaction(async (tx) => {
    await tx.productSerialUnit.delete({ where: { id: sId } })
    await syncProductQuantityFromVariants(tx, pid)
  })
  return NextResponse.json({ ok: true })
}

export async function PATCH(...args: Parameters<typeof __PATCH>) {
  return withDb(() => __PATCH(...args))
}
export async function DELETE(...args: Parameters<typeof __DELETE>) {
  return withDb(() => __DELETE(...args))
}
