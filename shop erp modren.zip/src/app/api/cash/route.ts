import { NextRequest, NextResponse } from 'next/server'
import { db, withDb } from '@/lib/db'
import { requireAuth, authErrorResponse } from '@/lib/auth'
import { requireModule, featureErrorResponse } from '@/lib/features'
import { parseSignedAmount } from '@/lib/amount'

export const dynamic = 'force-dynamic'

async function __GET() {
  let session
  try {
    session = await requireAuth()
  } catch (e) {
    const err = authErrorResponse(e)
    return NextResponse.json(err?.body, { status: err?.status })
  }
  try { await requireModule(session, 'cash') } catch (e) {
    const fe = featureErrorResponse(e); if (fe) return NextResponse.json(fe.body, { status: fe.status }); throw e
  }

  const [entries, agg] = await Promise.all([
    db.cashEntry.findMany({
      where: { tenantId: session.tenantId },
      orderBy: { id: 'desc' },
      take: 200,
    }),
    db.cashEntry.aggregate({
      where: { tenantId: session.tenantId },
      _sum: { amount: true },
    }),
  ])
  // `userId` on CashEntry is a plain string (no Prisma relation defined),
  // so resolve names with a separate lookup instead of `include`.
  const userIds = [...new Set(entries.map((e) => e.userId).filter(Boolean))] as string[]
  const users = userIds.length
    ? await db.user.findMany({
        where: { id: { in: userIds } },
        select: { id: true, name: true },
      })
    : []
  const userNameById = new Map(users.map((u) => [u.id, u.name]))
  const entriesWithNames = entries.map((e) => ({
    ...e,
    userName: e.userId ? (userNameById.get(e.userId) ?? null) : null,
  }))
  return NextResponse.json({
    balance: agg._sum.amount ?? 0,
    entries: entriesWithNames,
  })
}

async function __POST(req: NextRequest) {
  let session
  try {
    session = await requireAuth()
  } catch (e) {
    const err = authErrorResponse(e)
    return NextResponse.json(err?.body, { status: err?.status })
  }
  try { await requireModule(session, 'cash') } catch (e) {
    const fe = featureErrorResponse(e); if (fe) return NextResponse.json(fe.body, { status: fe.status }); throw e
  }

  const body = await req.json().catch(() => null)
  if (!body) {
    return NextResponse.json({ error: 'بيانات غير صالحة' }, { status: 400 })
  }
  // 🛡️ FIX: `Number()` returned NaN for "100-" / "−100" and silently lost the
  // sign for anything the client sent as text. Parse the sign explicitly so a
  // manual entry always moves the drawer in the direction the user asked for.
  const amount = parseSignedAmount(body.amount)
  if (amount === null || amount === 0) {
    return NextResponse.json({ error: 'المبلغ غير صالح' }, { status: 400 })
  }
  const created = await db.cashEntry.create({
    data: {
      tenantId: session.tenantId,
      source: 'manual',
      amount,
      note: body.note ? String(body.note) : null,
      userId: session.userId,
    },
  })
  return NextResponse.json(created, { status: 201 })
}

export async function GET(...args: Parameters<typeof __GET>) {
  return withDb(() => __GET(...args))
}
export async function POST(...args: Parameters<typeof __POST>) {
  return withDb(() => __POST(...args))
}
