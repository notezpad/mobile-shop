/**
 * Service Worker 2026 — نظام المحل PWA
 *
 * Features:
 *  ✅ Precaching (app shell + critical assets)
 *  ✅ Network-first for API (fresh data, cache fallback)
 *  ✅ Stale-while-revalidate for static assets (JS/CSS/images)
 *  ✅ Cache-first for fonts + icons
 *  ✅ Offline page fallback
 *  ✅ Background sync (flush outbox when network returns)
 *  ✅ Push notifications (display push from server)
 *  ✅ Skip-waiting on install (instant activation)
 *  ✅ Cache cleanup on activate
 *  ✅ Navigation preload (faster page loads)
 *  ✅ Message handler (client → SW communication)
 *  ✅ Periodic sync (optional, for background data refresh)
 */

const CACHE_VERSION = 'shop-erp-v6'
const OFFLINE_URL = '/offline.html'

// ─── Precache list ──────────────────────────────────────────
// 🛡️ 2026-09-27: app routes (dashboard/pos/products/settings/finance)
// USED to be listed here and precached as full HTML documents. That
// caused the "sidebar link sometimes doesn't open the page until I
// refresh" bug: Next.js's App Router does client-side transitions by
// fetching an RSC payload from the SAME pathname as the page (a plain
// GET, not a `navigate`-mode request) — and the catch-all handler below
// would serve the STALE PRECACHED FULL HTML for that exact URL instead
// of forwarding to the network, so the router silently got the wrong
// payload shape and the on-screen content never changed (URL/history
// still updated, which is why it looked random/intermittent). A full
// page refresh worked because that request IS `navigate`-mode, which
// always goes to the network first (see below). It was also a stale/
// cross-tenant risk on a shared device: a dashboard HTML precached for
// one logged-in tenant could get served to a different tenant later.
// Only truly static, non-personalized assets belong in this list now.
const PRECACHE_URLS = [
  '/offline.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
]

// 🛡️ v12 (2026-10-06) — «صفحات الطوارئ»: أغلفة HTML ثابتة 100%
// (كل البيانات بتتجيب client-side من الـ APIs — مفيش أي بيانات مستخدم/محل
// جوا ملف الصفحة نفسه — اتأكدنا من ده في فحص الكاش v11).
// ⚠️ مختلفة عن PRECACHE_URLS القديمة اللي شالت Bug 2026-09-27: دي مش بتتقدم
// في المسار العادي خالص — بتتقدم كـ «ملاذ أخير» فقط لما:
//   1) الطلب يكون navigate-mode كامل (طلبات RSC بتعدّي فوق الـ SW من الأول
//      بالـ early-return اللي فوق — فمستحيل تسمّم انتقالات الصفحات)،
//   2) والشبكة تكون وقعت (5xx / Error 1102) بلا أي نسخة مخزنة للطلب نفسه.
// النتيجة: حتى وقت انهيار كامل للـ Worker، المستخدم بيشوف التطبيق بدل
// صفحة Error 1102 البيضا — وده اللي حصل مع صفحة دليل المستخدم
// اللي كانت بتقع مع صفحات الإدارة لأن مفيش نسخة سليمة منها في الكاش.
const FALLBACK_PAGES = [
  '/pos',
  '/dashboard',
  '/products',
  '/inventory',
  '/customers',
  '/users',
  '/reports',
  '/branches',
  '/expenses',
  '/guide',
  '/login',
]

/** ملاذ أخير للتنقل: نسخة الطوارئ المخزنة عند التثبيت (لو الطلب نفسه مالوش نسخة) */
async function lastResortPage(request) {
  try {
    const path = new URL(request.url).pathname
    if (!FALLBACK_PAGES.includes(path)) return null
    return (await caches.match(path, { ignoreSearch: true })) || null
  } catch {
    return null
  }
}

// ─── Install: precache app shell ─────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => {
      // Cache what we can — ignore individual failures
      const base = cache.addAll(PRECACHE_URLS).catch(() => {})
      // 🛡️ v12: صفحات الطوارئ — واحدة واحدة (add بيفشل صامت لو الصفحة
      // مش متاحة وقت التثبيت، ومابكسرش التثبيت). كلها HITs من
      // الـ Static Assets فتكلفة التحميل ≈ صفر.
      FALLBACK_PAGES.forEach((u) => {
        cache.add(u).catch(() => {})
      })
      return base
    })
  )
  self.skipWaiting()
})

// ─── Activate: clean old caches + enable navigation preload ──
self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      // Delete old caches
      caches.keys().then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_VERSION)
            .map((key) => caches.delete(key))
        )
      ),
      // Enable navigation preload
      self.registration.navigationPreload?.enable(),
    ])
  )
  self.clients.claim()
})

// ─── Fetch handler ──────────────────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event

  // Skip non-GET (POST/PUT/PATCH/DELETE → always network)
  if (request.method !== 'GET') return

  const url = new URL(request.url)

  // Skip cross-origin (Paymob, Google Fonts, etc.)
  if (url.origin !== self.location.origin) return

  // 🛡️ 2026-09-27: Next.js's App Router fetches an RSC payload from the
  // SAME URL as the page itself when you click a <Link> (client-side
  // transition) — it's a plain GET, not a `navigate`-mode request, so it
  // would otherwise fall into the generic "static asset" cache below and
  // could be answered with a stale cached HTML document for that path
  // instead of the fresh RSC payload Next.js expects, silently breaking
  // the transition (see the note on PRECACHE_URLS above for the full
  // story). These requests must always go straight to the network with
  // no Service Worker caching involved.
  const isNextRouterRequest =
    request.headers.get('RSC') === '1' ||
    request.headers.has('Next-Router-State-Tree') ||
    request.headers.has('Next-Router-Prefetch') ||
    url.pathname.startsWith('/_next/data/') ||
    url.searchParams.has('_rsc')
  if (isNextRouterRequest) return

  // ── API requests → network-first ─────────────────────────
  if (url.pathname.startsWith('/api/')) {
    // 🛡️ /api/auth/* بيحدد مين مسجّل دخول — ممنوع يتخزن نهائياً
    if (url.pathname.startsWith('/api/auth/')) return
    // 🛡️ v10 (2026-10-06) — ROOT FIX لعرض «الأصفار» و«الموقع وقع وفضل واقع»:
    // الكود القديم كان بيخزّن *أي* رد في الكاش — حتى صفحة خطأ Cloudflare
    // (Error 1102 / 503 HTML) كانت تتخزن تحت رابط الـ API نفسه أو تحت رابط
    // الصفحة! فبعد أي انهيار مؤقت للـ Worker، الويب بيفضل يرجّع صفحة الخطأ
    // المخزنة، والواجهة بتطلع أصفار لحد ما المستخدم يمسح الكاش بنفسه.
    // دلوقتي: نخزّن الردود السليمة (ok) فقط، وعند 5xx نقدّم آخر نسخة سليمة
    // (لو أحدث من 60 ثانية) بدل الأصفار/صفحة الخطأ — بيانات قديمة بثواني
    // أحسن بكتير من شاشة فاضية عند مستخدم نقطة بيع.
    event.respondWith(
      (async () => {
        try {
          const response = await fetch(request)
          if (response && response.ok) {
            const clone = response.clone()
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone))
            return response
          }
          // 5xx → آخر نسخة سليمة لو طازة (≤ 60s)، وإلا مرّر رد الخطأ كما هو
          if (response && response.status >= 500) {
            const cached = await caches.match(request)
            if (cached) {
              const at = Date.parse(cached.headers.get('date') || '')
              if (!Number.isFinite(at) || Date.now() - at < 60_000) return cached
            }
          }
          return response
        } catch {
          // Offline → try cache, then 503
          const cached = await caches.match(request)
          return cached || new Response(
            JSON.stringify({ error: 'أنت غير متصل بالإنترنت' }),
            { status: 503, headers: { 'Content-Type': 'application/json' } }
          )
        }
      })()
    )
    return
  }

  // ── Navigation → network-first + preload + offline fallback
  if (request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          // Use navigation preload if available
          const preload = await event.preloadResponse
          if (preload) {
            // 🛡️ v10: نخزّن الرد السليم فقط — صفحة Error 1102/503 ممنوع تتخزن
            // (كانت بتتخزن قبل كده فالموقع بيفضل «واقع» من الكاش بعد ما يتعافى)
            if (preload.ok) {
              const clone = preload.clone()
              caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone))
              return preload
            }
            // 🛡️ v11 — ROOT FIX لمظهر «الموقع وقع»:
            // صفحة 5xx من Cloudflare (زي Error 1102 — Worker exceeded resource
            // limits) ممنوع نوصلها للمستخدم وهناك نسخة سليمة مخزنة. نقدّم آخر
            // نسخة HTML سليمة فورًا — التطبيق بيكمل شغال من الكاش والشل،
            // والبيانات بتتحدّث من الـ APIs لوحدها في الخلفية.
            // 🛡️ v12: لو مفيش نسخة للطلب نفسه (أول زيارة للصفحة دي) → نسخة
            // الطوارئ المخزنة عند التثبيت (FALLBACK_PAGES).
            const fallback = (await caches.match(request)) || (await lastResortPage(request))
            if (fallback) return fallback
            return preload
          }

          // Normal fetch
          const response = await fetch(request)
          if (response.ok) {
            const clone = response.clone()
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone))
            return response
          }
          // 🛡️ v11: نفس الحماية للـ fetch العادي (بدون preload)
          // 🛡️ v12: + نسخة الطوارئ لو مفيش نسخة للطلب نفسه
          if (response.status >= 500) {
            const fallback = (await caches.match(request)) || (await lastResortPage(request))
            if (fallback) return fallback
          }
          return response
        } catch {
          // Offline → cache → emergency page → offline page
          const cached = (await caches.match(request)) || (await lastResortPage(request))
          return cached || caches.match(OFFLINE_URL)
        }
      })()
    )
    return
  }

  // 🛡️ ROOT FIX: ملفات /_next/static/* أسماؤها فيها hash ومش بتتغير
  // أبداً. القديم كان stale-while-revalidate: يرجّع النسخة المخزنة
  // *ويعمل كمان ريكويست شبكة لنفس الملف في كل مرة* — أي ~25 ريكويست
  // زيادة على السيرفر في كل فتح صفحة بدون أي فايدة. دلوقتي cache-first
  // بالكامل: لو الملف موجود في الكاش خلاص، صفر شبكة.
  const isImmutable =
    url.pathname.startsWith('/_next/static/') ||
    url.pathname.startsWith('/fonts/')
  if (isImmutable) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached
        return fetch(request).then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone()
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone))
          }
          return response
        })
      })
    )
    return
  }

  // ── Static assets → stale-while-revalidate ───────────────
  event.respondWith(
    caches.match(request).then((cached) => {
      const fetchPromise = fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone()
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, clone))
          }
          return response
        })
        .catch(() => cached)

      return cached || fetchPromise
    })
  )
})

// ─── Background Sync: flush outbox when network returns ─────
self.addEventListener('sync', (event) => {
  if (event.tag === 'shop-erp-sync') {
    event.waitUntil(
      // Notify all clients to flush their outbox
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({ type: 'FLUSH_OUTBOX' })
        })
      })
    )
  }
})

// ─── Push notifications ──────────────────────────────────────
self.addEventListener('push', (event) => {
  if (!event.data) return

  let data
  try {
    data = event.data.json()
  } catch {
    data = { title: 'نظام المحل', body: event.data.text() }
  }

  const title = data.title || 'نظام المحل'
  const options = {
    body: data.body || data.message || '',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    dir: 'rtl',
    lang: 'ar',
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/dashboard',
    },
    actions: data.actions || [],
    tag: data.tag || 'shop-erp-notification',
    renotify: data.renotify || false,
  }

  event.waitUntil(
    self.registration.showNotification(title, options)
  )
})

// ─── Notification click ──────────────────────────────────────
self.addEventListener('notificationclick', (event) => {
  event.notification.close()

  const targetUrl = event.notification.data?.url || '/dashboard'

  event.waitUntil(
    self.clients.matchAll({ type: 'window' }).then((clientList) => {
      // Focus existing window if open
      for (const client of clientList) {
        if (client.url.includes(targetUrl) && 'focus' in client) {
          return client.focus()
        }
      }
      // Open new window
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl)
      }
    })
  )
})

// ─── Message handler (client → SW) ──────────────────────────
self.addEventListener('message', (event) => {
  if (!event.data) return

  switch (event.data.type) {
    case 'SKIP_WAITING':
      self.skipWaiting()
      break

    case 'PRECACHE_URLS':
      // Precache additional URLs sent by the client
      if (Array.isArray(event.data.urls)) {
        caches.open(CACHE_VERSION).then((cache) => {
          cache.addAll(event.data.urls).catch(() => {})
        })
      }
      break

    case 'CLEAR_CACHE':
      caches.delete(CACHE_VERSION).then(() => {
        event.source?.postMessage({ type: 'CACHE_CLEARED' })
      })
      break

    case 'GET_CACHE_SIZE':
      caches.open(CACHE_VERSION).then((cache) => {
        cache.keys().then((keys) => {
          event.source?.postMessage({ type: 'CACHE_SIZE', count: keys.length })
        })
      })
      break
  }
})

// ─── Periodic Sync (background data refresh) ─────────────────
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'shop-erp-refresh') {
    event.waitUntil(
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => {
          client.postMessage({ type: 'PERIODIC_REFRESH' })
        })
      })
    )
  }
})
