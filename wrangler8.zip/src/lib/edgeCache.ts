/**
 * ⚡ EDGE CACHE (2026-10-06) — إصلاح Error 1102 (Worker exceeded CPU time limit)
 * ─────────────────────────────────────────────────────────────────────────────
 * السياق: خطة Cloudflare المجانية بتيح 10ms CPU للطلب الواحد. كل طلب API
 * بيدفع تكلفة ثابتة (إنشاء PrismaClient جديد + محرك WASM + اتصال Postgres
 * بدون Hyperdrive) قبل أي منطق — فالحمل الزمني (مستخدم يتنقل بسرعة بين
 * الصفحات، داشبورد بيتحدث تلقائياً كل 5 دقايق + جرس الإشعارات كل 3 دقايق)
 * بيخلي سلسلة طلبات متتالية تعدي الحد → 1102 → Cloudflare بتعمل circuit
 * breaker مؤقت للموقع كله (بالهبوط والرجوع اللي شفناه في wrangler tail).
 *
 * الحل هنا: كاش على حافة Cloudflare (Cache API) للـ GET endpoints الثقيلة:
 *   - الرد المخزن بيتخدم من غير ما يشغّل الـ Worker أصلاً (≈ صفر CPU)
 *   - المفتاح per-tenant (بيانات كل محل منفصلة تماماً)
 *   - TTL قصير جداً (ثواني) عشان البيانات تفضل حديثة عملياً
 *   - أي mutation بتعمل purge للمفاتيح المتأثرة فوراً — فمفيش بيانات
 *     قديمة بعد إضافة عميل/فاتورة/سداد
 *   - على بيئة التطوير (Node) الكاش متجاهل تماماً (no-op) — السلوك زي ما هو
 *
 * 🔒 الأمان: المفتاح بيشمل tenantId + مسار الـ API + المعاملات المتعلقة
 * بالاستعلام فقط. مفيش أي بيانات مستأجر تاني ممكن تتسرب لأن المفتاح
 * نفسه ما بيتطابقش غير لنفس المستأجر، والكاش نفسه خارج المتصفح
 * (الـ response اللي بيوصل للمتصفح دايماً no-store).
 */

const CACHE_HOST = 'edge-cache.internal'

/** true لو شغالين داخل Cloudflare Workers (workerd) وليس Node dev */
export function edgeCacheAvailable(): boolean {
  try {
    const c = (globalThis as unknown as { caches?: { default?: { match?: unknown; put?: unknown } } }).caches
    return typeof c?.default?.match === 'function' && typeof c?.default?.put === 'function'
  } catch {
    return false
  }
}

/**
 * مفتاح كاش قياسي: path + معاملات مرتبة + tenantId.
 * بنمرر الـ searchParams مرتبة كـ string جاهزة (rawQuery) عشان المفتاح
 * يكون حتمي (deterministic) — نفس الطلب = نفس المفتاح دايماً.
 */
function buildKey(pathname: string, rawQuery: string, tenantId: number | string, v: string): Request {
  const q = rawQuery ? `?${rawQuery}` : ''
  return new Request(`https://${CACHE_HOST}${pathname}${q}#tenant=${tenantId}&v=${v}`)
}

/** رد مخزن؟ يرجع نسخة جاهزة للإرجاع للمتصفح (Cache-Control: no-store) */
export async function matchEdgeCache(
  pathname: string,
  rawQuery: string,
  tenantId: number | string,
  v = '1'
): Promise<Response | null> {
  if (!edgeCacheAvailable()) return null
  try {
    const hit = await (globalThis as unknown as { caches: { default: Cache } }).caches.default.match(
      buildKey(pathname, rawQuery, tenantId, v)
    )
    if (!hit) return null
    const fresh = new Response(hit.body, hit)
    // المتصفح دايماً يعيد الطلب — الكاش على الحافة فقط. مفيش stale في المتصفح
    // بعد أي mutation (الـ purge بيشتغل على الحافة فوراً).
    fresh.headers.set('Cache-Control', 'no-store')
    // 🛡️ ممنوع كوكي مستخدم يوصل لمستخدم تاني من نفس المحل
    fresh.headers.delete('Set-Cookie')
    return fresh
  } catch {
    return null
  }
}

/**
 * تخزين رد على الحافة بـ TTL قصير (ثواني). لا يفشل الطلب أبداً.
 * ملاحظة: مرّر نسخة `res.clone()` مش الرد الأصلي — الرد الأصلي يرجع للفريمورك.
 */
export async function putEdgeCache(
  res: Response,
  pathname: string,
  rawQuery: string,
  tenantId: number | string,
  ttlSeconds: number,
  v = '1'
): Promise<void> {
  if (!edgeCacheAvailable()) return
  if (res.status !== 200) return
  try {
    const stored = new Response(res.body, res)
    stored.headers.set('Cache-Control', `public, max-age=${ttlSeconds}`)
    stored.headers.delete('Set-Cookie')
    await (globalThis as unknown as { caches: { default: Cache } }).caches.default.put(
      buildKey(pathname, rawQuery, tenantId, v),
      stored
    )
  } catch {
    // الكاش ما يكسرش الرد أبداً (حجم/حصانة/ما شابه)
  }
}

/** مسح مفاتيح بعد mutations — فورية، عشان البيانات تفضل دقيقة 100% */
export async function purgeEdgeCache(
  entries: Array<{ pathname: string; rawQuery?: string }>,
  tenantId: number | string,
  v = '1'
): Promise<void> {
  if (!edgeCacheAvailable()) return
  try {
    const cache = (globalThis as unknown as { caches: { default: Cache } }).caches.default
    await Promise.all(
      entries.map((e) =>
        cache
          .delete(buildKey(e.pathname, e.rawQuery ?? '', tenantId, v))
          .catch(() => undefined)
      )
    )
  } catch {
    // تجاهل — الـ TTL هيمسح بالضرورة
  }
}

/** مفاتيح قياسية للمسح بعد أي تغيير في العملاء/المبيعات/المدفوعات */
export const PURGE_KEYS = {
  dashboard: (days: number | string) => ({ pathname: '/api/dashboard', rawQuery: `days=${days}` }),
  customersDefault: { pathname: '/api/customers', rawQuery: '' },
  /**
   * ⚡ v9: قائمة المنتجات الافتراضية (كاشير/شاشة المنتجات).
   * المفتاح بيشمل فرع المستخدم لأن GET بيفلتر بـ session.branchId —
   * مستخدمين في فروع مختلفة لنفس المحل لازم يشوفوا قوائم مختلفة.
   * rawQuery هنا مُصطنع (مش من URL) بس هو نفسه اللي بيتخزن بيه.
   */
  products: (branchId: number | null | undefined) => ({
    pathname: '/api/products',
    rawQuery: `branch=${branchId ?? 0}`,
  }),
  categories: { pathname: '/api/categories', rawQuery: '' },
  suppliers: { pathname: '/api/suppliers', rawQuery: '' },
}

/**
 * ⚡ v9: مسح كاش الكتالوج كله (منتجات + تصنيفات + موردين) بعد أي mutation
 * على أي واحد فيهم. أرخص وأأمن من تتبّع التقاطعات الدقيقة بين الجداول —
 * والعملية نفسها رخيصة (3 عمليات delete على الحافة).
 */
export async function purgeCatalogCaches(
  tenantId: number | string,
  branchId: number | null | undefined,
  v = '3'
): Promise<void> {
  await purgeEdgeCache([PURGE_KEYS.products(branchId), PURGE_KEYS.categories, PURGE_KEYS.suppliers], tenantId, v)
}

/* ═══════════════════════════════════════════════════════════════════════
   ⚡ v9 (2026-10-06): نماذج "النسخة التلقائية" (versioned cache)
   ───────────────────────────────────────────────────────────────────────
   الـ purge بالمفتاح الدقيق بيشتغل بس لما الاستدعاءات ليها شكل ثابت واحد
   (زي dashboard?days=7). لكن endpoints زي /api/sales ليها آلاف الفاريانتس
   (from/to/page/limit/…) — مسحهم كلهم واحد واحد مش عملي.

   الحل: رقم نسخة مخزن على الحافة نفسه (مفتاح خاص `#ver`). القراءة بتقرا
   النسخة الحالية وتستخدمها في المفتاح، وأي mutation بيزوّد الرقم بواحد →
   كل الفاريانتس القديمة بتبقى معدية (orphan) وتتصرف تلقائياً بـ TTL.
   تكلفة القراءة الإضافية = caches.match واحدة (زمن مهمل مقابل تشغيل
   استعلامات ثقيلة).
   ═════════════════════════════════════════════════════════════════════ */

const verKey = (pathname: string, tenantId: number | string) =>
  new Request(`https://${CACHE_HOST}${pathname}#ver&tenant=${tenantId}`)

async function readCacheVersion(pathname: string, tenantId: number | string): Promise<string> {
  if (!edgeCacheAvailable()) return '1'
  try {
    const hit = await (globalThis as unknown as { caches: { default: Cache } }).caches.default.match(
      verKey(pathname, tenantId)
    )
    const n = hit ? parseInt(await hit.text(), 10) : 1
    return Number.isFinite(n) && n > 0 ? String(n) : '1'
  } catch {
    return '1'
  }
}

/**
 * نسخة مخزنة مع حل رقم النسخة تلقائياً — استخدمها في الـ GET endpoints
 * متعددة الفاريانتس. بترجع null لو مفيش نسخة صالحة.
 */
export async function matchEdgeCacheV(
  pathname: string,
  rawQuery: string,
  tenantId: number | string,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _ttl?: number
): Promise<Response | null> {
  const v = await readCacheVersion(pathname, tenantId)
  return matchEdgeCache(pathname, rawQuery, tenantId, v)
}

/** تخزين مع رقم النسخة الحالي — مرّر res.clone() زي putEdgeCache بالظبط. */
export async function putEdgeCacheV(
  res: Response,
  pathname: string,
  rawQuery: string,
  tenantId: number | string,
  ttlSeconds: number
): Promise<void> {
  const v = await readCacheVersion(pathname, tenantId)
  await putEdgeCache(res, pathname, rawQuery, tenantId, ttlSeconds, v)
}

/**
 * إبطال فوري لكل الفاريانتس المخزنة لهذا المسار — نادِها بعد أي mutation
 * يمس الجدول اللي الـ endpoint بيقرأ منه. آمنة تماماً (لو الكاش مش متاح
 * بتعمل لا شيء).
 */
export async function bumpEdgeCache(pathname: string, tenantId: number | string): Promise<void> {
  if (!edgeCacheAvailable()) return
  try {
    const cache = (globalThis as unknown as { caches: { default: Cache } }).caches.default
    const cur = await readCacheVersion(pathname, tenantId)
    const next = String(parseInt(cur, 10) + 1)
    const stored = new Response(next, {
      headers: { 'Content-Type': 'text/plain', 'Cache-Control': 'public, max-age=86400' },
    })
    await cache.put(verKey(pathname, tenantId), stored)
    // 🛡️ احتياط: امسح آخر مفتاح معروف بحالة ما حد خزّن بنسخة أقدم
    await cache.delete(buildKey(pathname, '', tenantId, cur)).catch(() => undefined)
  } catch {
    /* الكاش ما يكسرش الـ mutation أبداً */
  }
}

/**
 * مفتاح rawQuery حتمي: باراميترات مرتبة أبجدياً — نفس الطلب بيفضل نفس
 * المفتاح مهما كان ترتيب الباراميترات في الـ URL.
 */
export function sortedQuery(url: string): string {
  try {
    const sp = new URL(url).searchParams
    const parts: string[] = []
    sp.forEach((val, key) => parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(val)}`))
    return parts.sort().join('&')
  } catch {
    return ''
  }
}
