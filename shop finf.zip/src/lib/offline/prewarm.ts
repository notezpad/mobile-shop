/**
 * Pre-warm engine — pulls shop data to IndexedDB when online.
 *
 * When the user opens the app while connected, this fetches:
 *   1. ALL products → store in IDB 'products' for offline POS search
 *   2. Key API responses → cache in IDB 'rows' for offline page loads
 *
 * This is the "sync" counterpart: pull data when online, use it offline.
 */

import { idb } from './idb'

/** The endpoints we pre-cache for offline page loads (IDB layer — طبقة api()). */
const PRECACHE_ENDPOINTS = [
  '/api/dashboard',
  '/api/products?status=all',
  '/api/customers',
  '/api/suppliers',
  '/api/categories',
  '/api/subscription',
  '/api/tenant',
  '/api/notifications?unread=false',
  // 🛡️ PWA OFFLINE ROOT FIX (2026-10-07): سيشن المستخدم لازم تتخزن في IDB
  // — من غيرها أي فتح أوفلاين بيرجع getMe() = null = طرد للصفحة الرئيسية.
  // (write-through في getMe() بتغطي معظم الحالات؛ ده ضمان إضافي)
  '/api/auth/me',
  // 🛡️ v11 (LOCAL-FIRST): مصادر الصفحات اللي بيتشتكي منها أوفلاين —
  // سجل المبيعات / المصروفات / الخزنة / أوامر الشراء / المخزون. من غيرها
  // أول فتح أوفلاين لصفحة ما اتفتحتش أونلاين كان بييجي فاضي + توست أحمر.
  '/api/sales?page=1&limit=50',
  '/api/expenses',
  '/api/cash',
  '/api/finance',
  '/api/purchase-orders',
  '/api/branches',
  '/api/inventory/movements',
  '/api/inventory/transfers',
  '/api/inventory/stocktake',
]

/**
 * 🛡️ PWA OFFLINE FIX v4 (2026-10-07): endpoints المخزون — بتتلحق بـ
 * كاش الـ SW نفسه (مش IDB فقط) لأن صفحات المخزون بتقرأ بـ fetch خام
 * مباشر، والـ fetch الخام أوفلاين بياخد جوابه من كاش الـ SW.
 * من غير كده صفحة المخزون كانت بتفتح أوفلاين بصفر + "الخطأ: رمز 503".
 *
 * ⚡ 2026-10-17 (تقليل CPU — الخطوة 3): اتشالت المكررات من القايمة
 * (branches/movements/transfers/stocktake كانوا موجودين مرتين — مرة من
 * PRECACHE_ENDPOINTS ومرة مكتوبين يدوي) — كل مكرر كان طلب Worker زيادة
 * عند كل دورة تسخين.
 */
const SW_API_ENDPOINTS = [
  ...PRECACHE_ENDPOINTS,
]

/**
 * 🛡️ PWA OFFLINE ROOT FIX (2026-10-07): تسخين أغلفة HTML للتطبيق عبر
 * رسالة PRECACHE_URLS للـ Service Worker — عشان إطلاق الـ PWA أوفلاين
 * (start_url = /dashboard?source=pwa) يلاقي الصفحة في كاش الـ SW حتى لو
 * المستخدم ما فتحهاش بنفس الـ query ده قبل كده. الـ SW بيتعامل مع الرسالة
 * بشكل متسامح (مسار-بمسار، بيسكب المتخزن أصلاً).
 */
const APP_SHELL_ROUTES = [
  '/login',
  '/dashboard',
  '/pos',
  '/products',
  '/sales',
  '/customers',
  '/inventory',
  // 🛡️ PWA OFFLINE FIX (2026-10-07): كل شاشات النظام — الضغط على أي لينك
  // من القايمة الجانبية أوفلاين لازم يفتح الصفحة من الكاش بدل ERR_FAILED
  // أو صفحة "أنت غير متصل". الصفحات كلها prerendered على الحافة فالتسخين رخيص.
  '/suppliers',
  '/purchases',
  '/expenses',
  '/cash',
  '/reports',
  '/finance',
  '/inventory/movements',
  '/inventory/transfers',
  '/inventory/stocktake',
  '/settings',
  '/branches',
  '/users',
  '/maintenance',
  '/guide',
]

/**
 * 🛡️ PWA OFFLINE FIX v4: بعد أي تحديث للـ Service Worker الكاش بيتعمله
 * wipe (activate بيمسح الكاشات القديمة) — فالثروتل 20-دقيقة كان هيمنع
 * إعادة التسخين والجهاز يفضل أوفلاين فاضي! بنلغي الثروتل لحظة ما SW
 * جديد ياخد الكونترول (controllerchange) فأول دورة sync تالية تعيد
 * تسخين كل حاجة تلقائياً.
 */
let swResetInstalled = false
export function installPrewarmResetOnSwUpdate(): void {
  if (swResetInstalled || typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return
  swResetInstalled = true
  try {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      void idb.setMeta('lastPrewarmAt', 0).catch(() => {})
    })
  } catch {
    /* ignore */
  }
}

/**
 * 🛡️ PWA OFFLINE FIX v4: إرسال ردود الـ API لكاش الـ SW (الطبقة اللي
 * بتقرأ منها fetches الخام أوفلاين) — رسالة PRECACHE_APIS، متسامحة
 * URL-بـ-URL جوا الـ SW نفسه.
 *
 * ⚡ 2026-10-17 (تقليل CPU — الخطوة 3): ثروتل 10 دقايق — الطلبات دي أصلاً
 * بتتخزن في كاش الـ SW تلقائيًا أثناء الاستخدام الطبيعي (fetch handler
 * بيخزن أي /api GET سليم)، فإعادة "التسخين" الصريحة مش لازم تحصل مع كل
 * دورة sync. أول تفعيل/تحديث SW بيفضل شغال فورًا لأن الثروتل بيتصفّر
 * مع reset الـ prewarm (installPrewarmResetOnSwUpdate).
 */
const SW_API_WARM_TTL_MS = 10 * 60 * 1000
async function warmSwApiCache(): Promise<void> {
  try {
    if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return
    const lastWarm = await idb.getMeta<number>('lastSwApiWarmAt')
    const lastPrewarm = await idb.getMeta<number>('lastPrewarmAt')
    // reset بعد تحديث الـ SW بيتعمل بوضع lastPrewarmAt = 0 (شوف
    // installPrewarmResetOnSwUpdate) — في الحالة دي بنسمح بالتسخين فورًا.
    const swJustReset = lastPrewarm === 0
    if (lastWarm && Date.now() - lastWarm < SW_API_WARM_TTL_MS && !swJustReset) {
      return // اتسخّن حالًا — متضغطش الـ Worker من غير لزوم
    }
    const reg = await navigator.serviceWorker.ready
    const sw = reg?.active
    if (!sw) return
    sw.postMessage({ type: 'PRECACHE_APIS', urls: SW_API_ENDPOINTS })
    await idb.setMeta('lastSwApiWarmAt', Date.now())
  } catch {
    /* ignore */
  }
}

export async function prewarmAppShell(): Promise<void> {
  try {
    if (typeof navigator === 'undefined') return
    if (!('serviceWorker' in navigator)) return
    const reg = await navigator.serviceWorker.ready
    const sw = reg?.active
    if (!sw) return
    sw.postMessage({ type: 'PRECACHE_URLS', urls: APP_SHELL_ROUTES })
  } catch {
    /* ignore */
  }
}

/**
 * Pull all products into IndexedDB for offline POS search.
 * Fetches with status=all to get every product (active + inactive).
 *
 * 🛡️ PWA OFFLINE FIX v5 (2026-10-07) — جذر "البحث أوفلاين بيقلك غير متصل":
 * /api/products بيرجع دايماً ظرف { data, total, page, limit, totalPages } —
 * النسخة القديمة كانت بتستنى Array فشرط Array.isArray كان بيفشل دايماً →
 * replaceProducts عمره ما كان بينادي → متجر products في IDB كان فاضي →
 * أي بحث أوفلاين (نقطة البيع/المنتجات/أمر الشراء) كان بيرجع "غير متصل".
 * كمان السيرفر بيحد limit بـ 100 كحد أقصى فبنمشي بالترقيم لحد ما نكمّل total.
 */
export async function prewarmProducts(): Promise<number> {
  try {
    const LIMIT = 100
    const MAX_PAGES = 60 // سقف أمان: 6000 منتج
    const all: any[] = []
    for (let page = 1; page <= MAX_PAGES; page++) {
      const res = await fetch(`/api/products?status=all&limit=${LIMIT}&page=${page}`)
      if (!res.ok) break
      const raw = await res.json().catch(() => null)
      const arr = Array.isArray(raw)
        ? raw
        : raw && Array.isArray(raw.data)
          ? raw.data
          : null
      if (!arr || arr.length === 0) break
      all.push(...arr)
      const total = Number(raw?.total ?? all.length)
      // آخر صفحة: مفيش زيادة عن total أو الصفحة جت ناقصة
      if (!(total > all.length) || arr.length < LIMIT) break
    }
    if (all.length === 0) return 0
    await idb.replaceProducts(all)
    await idb.setMeta('productsPrewarmedAt', Date.now())
    return all.length
  } catch {
    return 0
  }
}

/**
 * Pre-cache key API endpoints so pages load instantly offline.
 */
export async function prewarmEndpoints(): Promise<number> {
  let cached = 0
  for (const url of PRECACHE_ENDPOINTS) {
    try {
      const res = await fetch(url, { cache: 'default' })
      if (!res.ok) continue
      const data = await res.json()
      await idb.setCached(url, data)
      cached++
    } catch {
      /* skip failed endpoints */
    }
  }
  // 🛡️ v4: وبالتوازي — نسخّن كاش الـ SW برضه (لصفحات الـ fetch الخام):
  // بنسيبه في الخلفية عشان منعطلش رجوع العدد للمُنادي.
  void warmSwApiCache()
  return cached
}

/**
 * Full pre-warm: products + endpoints. Called on app boot when online.
 * Returns { products, endpoints } counts.
 */
export async function prewarmAll(): Promise<{ products: number; endpoints: number }> {
  if (typeof navigator === 'undefined' || navigator.onLine === false) {
    return { products: 0, endpoints: 0 }
  }

  // 🛡️ v4: لو SW جديد استلم الكونترول (تحديث) بنلغي الثروتل — الكاش
  // الجديد فاضي ومحتاج تسخين كامل فوراً. (idempotent — بنسجعه مرة واحدة)
  installPrewarmResetOnSwUpdate()

  // 🛡️ v4: أغلفة الصفحات بتتسخّن مع كل دورة sync — الـ SW بيسكب المتخزن
  // أصلاً (cache.match قبل الـ fetch) فتكلفة الدورة شبه صفر، وميزة الأمان
  // كبيرة: أي صفحة جديدة اتقفلت من كاش تحديث SW بترجع تلقائياً.
  void prewarmAppShell()
  // ⚡ 2026-10-17: تسخين كاش الـ API بقى مُثروتل (10 دقايق) بدل كل دورة —
  // الأصناف نفسها بتتخزن أصلاً أثناء الاستخدام الطبيعي عبر الـ fetch handler.
  void warmSwApiCache()

  // Check if we already pre-warmed recently (within 20 minutes) —
  // المنتجات والـ endpoints دي الأتقل (سحب كامل) فبنعملها بالثروتل فقط.
  const lastPrewarm = await idb.getMeta<number>('lastPrewarmAt')
  if (lastPrewarm && Date.now() - lastPrewarm < 20 * 60 * 1000) {
    // Already warmed recently — skip
    return { products: 0, endpoints: 0 }
  }

  const [products, endpoints] = await Promise.all([
    prewarmProducts(),
    prewarmEndpoints(),
  ])

  await idb.setMeta('lastPrewarmAt', Date.now())

  return { products, endpoints }
}

/**
 * Check if the products store has been pre-warmed.
 */
export async function isPrewarmed(): Promise<boolean> {
  const count = await idb.productCount()
  return count > 0
}
