/**
 * Server-only plan helpers (require DB access).
 *
 * 🛡️ 2026-09-15 (v2): Constants + pure helpers split out to
 * `plan-constants.ts` (CLIENT-SAFE — no db import). This file re-exports
 * them so existing API routes keep working with the same import path.
 *
 * DO NOT import this file from a client component — it pulls in the server
 * SQL client (`postgres.js`) which breaks the browser bundle. Use
 * `@/lib/plan-constants` for client code.
 */

import type { Session } from './auth'
// ⚡ 2026-10-17 (تقليل CPU): features.ts ماعادش يستورد Prisma — خطة المحل
// بترجع باستعلام SQL واحد (Subscription JOIN Plan) عبر postgres.js.
import { getSql } from './sql'

// 🛡️ Re-export client-safe constants + types so existing server imports
// (`import { CRITICAL_MODULES, ALL_MODULES, requireModule } from '@/lib/features'`)
// keep working without any code changes.
export {
  ALL_MODULES,
  ALL_CAPABILITIES,
  CRITICAL_MODULES,
  isCriticalModule,
} from './plan-constants'
export type { ModuleKey, Capability } from './plan-constants'

import type { ModuleKey, Capability } from './plan-constants'
import { CRITICAL_MODULES, enforceVerticalRules } from './plan-constants'
// 🧩 2026-11-04 (التحديث 25): مفاتيح الإضافات المدفوعة (HR / فروع / مستخدمين)
import { ADDON_KEYS } from './addons'

function safeParseArray(raw: string | null | undefined): string[] | null {
  if (!raw) return null
  try {
    const v = JSON.parse(raw)
    if (Array.isArray(v)) return v.map(String)
  } catch {
    /* ignore */
  }
  return null
}

export type PlanContext = {
  // 🥬 2026-10-12: أضفنا 'food' (المواد الغذائية: عطارة/مجمدات/بقالة/منظفات)
  businessType: 'electronics' | 'fashion' | 'food'
  enabledModules: string[]
  capabilities: string[]
  /** 🧩 2026-11-04 (التحديث 25): الإضافات المدفوعة النشطة — بدون تكرار.
   * 'hr' = الموارد البشرية مفتوحة على باقة أساسية، والحدود تحت بتشمل كميات
   * الفروع/المستخدمين الإضافية المشتراة. */
  addOns: string[]
  /** 🛡️ 2026-10-10: حدود الباقة — بتتقرا من نفس Plan المحفوظ.
   * لو مفيش اشتراك/باقة (tenant منتهي مثلاً) القيمة = UNLIMITED_PLAN_LIMIT
   * عشان ما نمنعش مرتين — الـ auth layer هو اللي بيقفل المنتهي أصلاً. */
  limits: {
    maxUsers: number
    maxProducts: number
    maxBranches: number
  }
}

/**
 * 🛡️ 2026-10-10: تمثيل "غير محدود" في الـ admin UI (plan-shared.tsx).
 * أي حد >= القيمة دي بيتعامل كأنه بلا حدود (مفيش فحص).
 */
export const UNLIMITED_PLAN_LIMIT = 999_999

export type LimitKind = 'users' | 'products' | 'branches'

const LIMIT_KIND_LABEL: Record<LimitKind, string> = {
  users: 'مستخدمين',
  products: 'منتجات',
  branches: 'فروع',
}

/**
 * Resolve the enabled modules + capabilities for a tenant.
 * Legacy plans (no enabledModules) get ALL_MODULES for backwards compat.
 *
 * 🛡️ 2026-09-15 (v2): CRITICAL_MODULES is now just [settings, users] —
 * we always add these two, but everything else (maintenance, finance,
 * expenses, cash, etc.) is gated by the plan's enabledModules.
 *
 * 🛡️ 2026-09-15 (v3) · محدّث 2026-10-05 (v7): Added runtime vertical-rules
 * enforcement. Even if the DB still has the OLD broken config (e.g.
 * fashion-basic with maintenance in its modules list, or capabilities
 * = [] without 'variants'), `enforceVerticalRules` will silently fix it
 * for the 4 canonical plans:
 *   - fashion plans (basic AND pro) → strip maintenance, finance,
 *     expenses, cash; ensure 'variants' capability is present (so
 *     clothing shops — retail chains included — can always add
 *     sizes/colors to products)
 *   - electronics-basic/pro → keep everything the DB says
 *
 * This means the user gets the correct UX immediately after deploying
 * the code, WITHOUT needing to apply the SQL migration. The migration
 * is still recommended (it cleans up the DB rows for hygiene) but it's
 * no longer strictly required for the runtime to behave correctly.
 */
const PLAN_CTX_TTL_MS = 60_000
const planCtxCache = new Map<string, { at: number; value: PlanContext }>()

export async function getPlanContext(tenantId: string): Promise<PlanContext> {
  const hit = planCtxCache.get(tenantId)
  if (hit && Date.now() - hit.at < PLAN_CTX_TTL_MS) return hit.value
  const value = await loadPlanContext(tenantId)
  if (planCtxCache.size > 500) planCtxCache.clear()
  planCtxCache.set(tenantId, { at: Date.now(), value })
  return value
}

/**
 * 🧩 2026-11-04 (التحديث 25): إبطال كاش سياق الباقة لمحل معين.
 * بيتنادى بعد تفعيل/إلغاء إضافة (webhook Paymob / منح الأدمن) عشان
 * الإضافة تظهر فوراً من غير ما نستنى انتهاء الـ TTL (60 ثانية).
 */
export function invalidatePlanContextCache(tenantId: string): void {
  planCtxCache.delete(tenantId)
}

async function loadPlanContext(tenantId: string): Promise<PlanContext> {
  // ⚡ استعلام واحد بدل findFirst + include plan (مرة واحدة على الشبكة)
  const sql = getSql()
  type Row = {
    code: string | null
    businessType: string | null
    enabledModules: string | null
    capabilities: string | null
    maxUsers: number | null
    maxProducts: number | null
    maxBranches: number | null
  }
  const rows = await sql<Row[]>`
    SELECT p."code", p."businessType", p."enabledModules", p."capabilities",
           p."maxUsers", p."maxProducts", p."maxBranches"
    FROM "Subscription" s
    JOIN "Plan" p ON p."id" = s."planId"
    WHERE s."tenantId" = ${tenantId} AND s."status" = 'active'
    ORDER BY s."endDate" DESC
    LIMIT 1`
  const plan = rows[0] ?? null

  // 🧩 2026-11-04 (التحديث 25): الإضافات المدفوعة النشطة — استعلام خفيف ثانٍ.
  // شرط الـ endDate > now() هو اللي بيقفل الإضافة تلقائياً يوم انتهائها
  // (من غير cron ولا مهام مجدولة). الكميات بتتراكم: صفّين extra_branch
  // نشطين بكمية 2 و 1 = +3 فروع فوق حد الباقة.
  // 🛡️ لو الـ migration مش متطبقة بعد (الجدول لسه ماعملش) — ممنوع الدهmma
  // دي تكسر سياق الباقة كله: بنرجّع قائمة فاضية والباقي يشتغل عادي.
  type AddOnRow = { addOnKey: string; quantity: number }
  let addOnRows: AddOnRow[] = []
  try {
    addOnRows = await sql<AddOnRow[]>`
      SELECT "addOnKey", "quantity"
      FROM "TenantAddOn"
      WHERE "tenantId" = ${tenantId}
        AND "status" = 'active'
        AND "endDate" > now()
        AND "addOnKey" IN (${ADDON_KEYS})`
  } catch {
    addOnRows = []
  }
  const addOnQty = new Map<string, number>()
  for (const r of addOnRows) {
    if (!(ADDON_KEYS as readonly string[]).includes(r.addOnKey)) continue
    addOnQty.set(r.addOnKey, (addOnQty.get(r.addOnKey) ?? 0) + Math.max(1, Number(r.quantity) || 1))
  }
  const addOns = Array.from(addOnQty.keys())

  const parsedModules = safeParseArray(plan?.enabledModules ?? null)
  // 🛡️ Force-include the CRITICAL_MODULES in EVERY plan response
  // (just settings + users — everything else is plan-gated)
  const moduleSet = new Set<string>(parsedModules ?? [...ALL_MODULES_LOCAL])
  for (const m of CRITICAL_MODULES) moduleSet.add(m)
  // 🧩 إضافة HR المشتَراة بتتضاف هنا (وقبل قواعد النشاط عشان نعرف نحترمها)
  if (addOns.includes('hr')) moduleSet.add('hr')
  const caps = safeParseArray(plan?.capabilities ?? null) ?? []
  // 🥬 2026-10-12: النشاط الغذائي 'food' — بيتقرا زي ما هو، وأي قيمة
  // تانية غير معروفة بترجع 'electronics' (نفس السلوك القديم).
  const businessType = (
    plan?.businessType === 'fashion' ? 'fashion' : plan?.businessType === 'food' ? 'food' : 'electronics'
  ) as 'electronics' | 'fashion' | 'food'

  // 🛡️ 2026-09-15 (v3): Apply vertical rules at runtime — fixes the
  // user's "still seeing maintenance + finance in fashion plan" bug
  // even if they haven't applied the migration SQL yet.
  // 🧩 بنمرر الإضافات عشان قاعدة «الأساسية بدون HR» ما تمسحش إضافة مدفوعة.
  const enforced = enforceVerticalRules(
    plan?.code ?? null,
    businessType,
    Array.from(moduleSet),
    caps,
    addOns,
  )

  return {
    businessType,
    enabledModules: enforced.modules,
    capabilities: enforced.capabilities,
    addOns,
    limits: {
      // 🧩 الفروع/المستخدمين الإضافيين بيزيدوا الحد فوق قيمة الباقة
      maxUsers: (plan?.maxUsers ?? UNLIMITED_PLAN_LIMIT) + (addOnQty.get('extra_users') ?? 0),
      maxProducts: plan?.maxProducts ?? UNLIMITED_PLAN_LIMIT,
      maxBranches: (plan?.maxBranches ?? UNLIMITED_PLAN_LIMIT) + (addOnQty.get('extra_branch') ?? 0),
    },
  }
}

// Local alias to ALL_MODULES to avoid a circular import — plan-constants
// doesn't import from this file, so the alias is safe.
import { ALL_MODULES as ALL_MODULES_LOCAL } from './plan-constants'

export async function getTenantModules(tenantId: string): Promise<string[]> {
  const ctx = await getPlanContext(tenantId)
  return ctx.enabledModules
}

export class FeatureError extends Error {
  status: number
  constructor(message: string, status = 403) {
    super(message)
    this.name = 'FeatureError'
    this.status = status
  }
}

/**
 * Throw FeatureError if module not in the tenant's plan.
 *
 * 🛡️ 2026-09-15 (v2): Only `settings` and `users` bypass this check.
 * Maintenance, finance, expenses, cash are now properly gated — only
 * electronics plans can access them.
 */
/**
 * 🔐 2026-10-18 — صلاحيات الموظف (user.permissions) على السيرفر.
 *
 * قبل كده الصلاحيات كانت بتتطبق في الواجهة بس (السايدبار بيخبّي الصفحات)، فأي موظف
 * ممكن يبعت طلب مباشر لـ API الموردين/المشتريات/المخزون ويدفع لمورد من الخزنة أو
 * يلغي أمر شراء. دلوقتي نفس القاعدة بتتفرض هنا:
 *   - المدير: بدون قيود.
 *   - موظف بدون permissions (null/فاضية): كل اللي بتسمح بيه الباقة (زي السايدبار بالظبط).
 *   - موظف بـ permissions: لازم الموديول (أو أي موديول مرتبط) يكون ضمنها.
 *
 * 🛡️ 2026-10-19 — التوسعة لكل الموديولات (المرحلة 2): نفس الفرض بقى على كل
 * شاشة مستقلة (مبيعات / منتجات / عملاء / لوحة معلومات / تقارير الفروع...).
 * الشاشات المشتركة محمية بالـ aliases تحت عشان نقطة البيع ما تتعطلش:
 *   - كتالوج المنتجات بيتقري من نقطة البيع والمشتريات والمخزون.
 *   - العملاء بيتقروا من نقطة البيع وسجل المبيعات.
 *   - البيع نفسه موديوله 'pos' (مش 'sales' — سجل المبيعات شاشة مستقلة).
 * الكتابة بتفرض الموديول نفسه بدون aliases — شوف requireModuleWrite تحت.
 */
const PERMISSION_ALIASES: Partial<Record<ModuleKey, ModuleKey[]>> = {
  inventory: ['inventory'],
  // شاشة الشراء بتحتاج قايمة الموردين، وشاشة الموردين بتعرض أوامر شرائهم
  suppliers: ['suppliers', 'purchases'],
  purchases: ['purchases'],
  // 🆕 المرحلة 2 — باقي الموديولات:
  dashboard: ['dashboard'],
  pos: ['pos'],
  // كتالوج المنتجات قراءة مشتركة (نقطة البيع/المشتريات/المخزون/الذكاء الاصطناعي)
  products: ['products', 'pos', 'purchases', 'inventory'],
  // 🔒 2026-10-31: سجل المبيعات بقى للـ 'sales' فقط — شيلنا alias 'pos'
  // لأن نقطة البيع مابتقراش القايمة (بيع = requireModuleWritePermission('pos'))،
  // وترك alias القراءة بيخلّي كاشير نقطة البيع يقدر يسحب سجل مبيعات المحل
  // كله من الـ API مباشرة — وده اللي المالك خايف منه. المرتجع للكاشير بقى
  // له بوابته المستقلة (صلاحية 'returns' + lookup لفاتورة واحدة) — شوف
  // requireSaleReturnAccess تحت.
  sales: ['sales'],
  maintenance: ['maintenance'],
  // العملاء بيتقروا من نقطة البيع وسجل المبيعات
  customers: ['customers', 'pos', 'sales'],
  finance: ['finance'],
  expenses: ['expenses'],
  cash: ['cash'],
  reports: ['reports'],
  users: ['users'],
  branches: ['branches'],
  hr: ['hr'],
  settings: ['settings'],
}

/**
 * ✍️ الكتابة بتفرض الموديول نفسه (أو alias مكتوب هنا صراحةً) — عشان موظف نقطة
 * البيع (pos) يقدر يبيع، لكن ما يقدرش ينشئ/يعدّل منتجات أو عملاء من الـ API
 * مباشرةً ولو كان قراءتهم مسموحة له.
 * أي موديول مش موجود في الخريطة = الكتابة بتفرض الموديول نفسه فقط.
 */
// 🔁 القيم string[] مش ModuleKey[] — عشان صلاحية المرتجع المستقلة 'returns'
// (مش موديول/صفحة) تقدر تفتح باب كتابة موديول 'sales'.
const WRITE_ALIASES: Partial<Record<ModuleKey, readonly string[]>> = {
  // البيع فعل هو شغلانة نقطة البيع
  pos: ['pos'],
  // إتمام شراء من شاشة المشتريات — الدفع للمورد جزء من نفس الشغلانة (زي قبل كده)
  suppliers: ['suppliers', 'purchases'],
  purchases: ['purchases'],
  // 🔁 2026-10-31: مرتجع البيع بيتقبل من اتنين:
  //   'sales'  — من شاشة سجل المبيعات (المالك/الموظف المصرّح له).
  //   'returns' — صلاحية المرتجع المستقلة: كاشير نقطة البيع يستلم مرتجع
  //               من زرار «مرتجع فاتورة» جوه نقطة البيع نفسها — من غير ما
  //               يشوف سجل المبيعات ولا الأرباح خالص.
  sales: ['sales', 'returns'],
}

/**
 * 🔁 2026-10-31 — صلاحية البحث عن فاتورة لغرض المرتجع (GET /api/sales/returns/lookup).
 *
 * دي مش صلاحية قراءة سجل المبيعات — بترجع فاتورة واحدة بس (اللي هيعمل منها
 * مرتجع) بدون أي تكاليف أو أرباح أو قوائم مبيعات. المسموح:
 *   - المدير / SUPER_ADMIN.
 *   - موظف من غير قائمة صلاحيات (وضع افتراضي زي السايدبار).
 *   - موظف عنده 'sales' (سجل المبيعات) أو 'returns' (صلاحية المرتجع المستقلة).
 */
export function requireSaleReturnAccess(
  session: { role: string; permissions?: string[] | null },
) {
  if (session.role !== 'EMPLOYEE') return
  const p = session.permissions
  if (!p || p.length === 0) return
  if (!p.includes('sales') && !p.includes('returns')) {
    throw new FeatureError('ليس لديك صلاحية لهذه العملية', 403)
  }
}

/**
 * 🕐 2026-10-31 (التحديث الثامن): صلاحية إغلاق الوردية (الجرد الأعمى للدرج).
 * زي requireSaleReturnAccess بالظبط — مدير، أو موظف من غير قيود، أو موظف
 * عنده 'shift_close' (صلاحية مستقلة مش موديول — بتتحدد في شاشة المستخدمين
 * جنب نقطة البيع). الكاشير بيكتب اللي عدّاه بس، والأرقام للمدير.
 */
export function requireShiftCloseAccess(
  session: { role: string; permissions?: string[] | null },
) {
  if (session.role !== 'EMPLOYEE') return
  const p = session.permissions
  if (!p || p.length === 0) return
  if (!p.includes('shift_close')) {
    throw new FeatureError('ليس لديك صلاحية لهذه العملية', 403)
  }
}

/**
 * 🔗 2026-11-01 (التحديث السادس عشر): صلاحية فتح الوردية — نفس نمط
 * requireShiftCloseAccess بالظبط: مدير، أو موظف من غير قيود، أو موظف
 * عنده 'shift_open' (صلاحية مستقلة جنب 'shift_close' في شاشة المستخدمين).
 * الفتح بيسجل جلسة الوردية (مين فتح + العهدة الافتتاحية) عشان الفارق
 * وقت الإغلاق يتحسب على الوردية نفسها بدل رصيد الدرج الكامل.
 */
export function requireShiftOpenAccess(
  session: { role: string; permissions?: string[] | null },
) {
  if (session.role !== 'EMPLOYEE') return
  const p = session.permissions
  if (!p || p.length === 0) return
  if (!p.includes('shift_open')) {
    throw new FeatureError('ليس لديك صلاحية لهذه العملية', 403)
  }
}

/**
 * 👤 2026-11-01 (التحديث السابع عشر): صلاحية صفحة «ملفي» — نفس النمط المستقل
 * بالظبط: مدير، أو موظف من غير قائمة صلاحيات، أو موظف عنده 'my_profile'.
 * الصفحة بتوريك بياناتك انت بس (مفيش أي بيانات حد تاني) + مبيعاتك النهاردة
 * + الوردية المفتوحة على فرعك + عمولتك لو بائع + ملفك في الموارد البشرية
 * (حضورك وإجازاتك وقسيمة راتبك). المالك يقدر يقفل الصفحة على موظف معين
 * بمجرد ما يشيلها من صلاحياته.
 */
export function requireMyProfileAccess(
  session: { role: string; permissions?: string[] | null },
) {
  if (session.role !== 'EMPLOYEE') return
  const p = session.permissions
  if (!p || p.length === 0) return
  if (!p.includes('my_profile')) {
    throw new FeatureError('ليس لديك صلاحية لهذه العملية', 403)
  }
}

/**
 * 🫥 2026-10-31 (التحديث الحادي عشر): صلاحية «إجراء الجرد الأعمي» —
 * نفس النمط بالظبط: مدير، أو موظف من غير قائمة صلاحيات، أو موظف عنده
 * 'blind_stocktake' (صلاحية مستقلة مش موديول — جنب نقطة البيع في شاشة
 * المستخدمين). بتفتح محطة الجرد بس: العدّ من غير رؤية أي أرقام — لا كميات
 * النظام ولا الفروق ولا التكاليف، والاعتماد يفضل للأدمن زي ما هو.
 */
export function requireBlindStocktakeAccess(
  session: { role: string; permissions?: string[] | null },
) {
  if (session.role !== 'EMPLOYEE') return
  const p = session.permissions
  if (!p || p.length === 0) return
  if (!p.includes('blind_stocktake')) {
    throw new FeatureError('ليس لديك صلاحية لهذه العملية', 403)
  }
}

/**
 * 🫥 (التحديث الحادي عشر) — هل السيشن ده «مدير» بنظرة الجرد؟
 * المدير (غير الموظف) هو الوحيد اللي يشوف أرقام النظام والفروق في أوراق
 * الجرد الأعمي — أي طلب من موظف بيرجع من غير systemQty/diff جوه الـ SQL.
 */
export function isStocktakeManager(session: { role: string }): boolean {
  return session.role !== 'EMPLOYEE'
}

/**
 * 💰 2026-11-01 (التحديث الثالث عشر) — صلاحية شاشة «عمولات البائعين».
 * نفس النمط المستقل: مدير، أو موظف من غير قائمة صلاحيات، أو موظف عنده
 * 'commissions' (صلاحية مستقلة مش موديول — جنب نقطة البيع في شاشة
 * المستخدمين). بتفتح تقرير العمولات الشهري + التسوية (والتسوية نفسها
 * بتفرض أدمن على السيرفر فوق كده).
 * ملاحظة: عرض البائع لعمولته هو لوحده مسار منفصل (/api/commissions/my)
 * ومش محتاج الصلاحية دي — ده رقمه هو.
 */
export function requireCommissionsAccess(
  session: { role: string; permissions?: string[] | null },
) {
  if (session.role !== 'EMPLOYEE') return
  const p = session.permissions
  if (!p || p.length === 0) return
  if (!p.includes('commissions')) {
    throw new FeatureError('ليس لديك صلاحية لهذه العملية', 403)
  }
}

export function requireModulePermission(
  session: { role: string; permissions?: string[] | null },
  moduleKey: ModuleKey,
) {
  if (session.role !== 'EMPLOYEE') return
  const allowedKeys = PERMISSION_ALIASES[moduleKey]
  if (!allowedKeys) return
  const p = session.permissions
  if (!p || p.length === 0) return
  if (!allowedKeys.some((k) => p.includes(k))) {
    throw new FeatureError('ليس لديك صلاحية لهذه العملية', 403)
  }
}

/**
 * ✍️ 2026-10-19: نفس فكرة requireModulePermission لكن للعمليات اللي بتكتب
 * (إنشاء/تعديل/حذف). بتفرض الموديول نفسه بدون aliases القراءة، مع استثناءات
 * WRITE_ALIASES للحالات اللي الكتابة فيها جزء أصيل من موديول تاني.
 * المدير/SUPER_ADMIN أو الموظف من غير قائمة صلاحيات = بدون قيود (زي السايدبار).
 */
export function requireModuleWritePermission(
  session: { role: string; permissions?: string[] | null },
  moduleKey: ModuleKey,
) {
  if (session.role !== 'EMPLOYEE') return
  const p = session.permissions
  if (!p || p.length === 0) return
  const allowedKeys = WRITE_ALIASES[moduleKey] ?? [moduleKey]
  if (!allowedKeys.some((k) => p.includes(k))) {
    throw new FeatureError('ليس لديك صلاحية لهذه العملية', 403)
  }
}

export async function requireModule(
  session: Pick<Session, 'tenantId' | 'role'> & { permissions?: string[] | null },
  moduleKey: ModuleKey,
) {
  // Super admin bypasses all module gating.
  if (session.role === 'SUPER_ADMIN') return
  // 🔐 صلاحيات الموظف (قبل فحص الباقة)
  requireModulePermission(session, moduleKey)
  // 🛡️ Critical modules bypass the plan check — always allowed.
  if ((CRITICAL_MODULES as readonly string[]).includes(moduleKey)) return
  const modules = await getTenantModules(session.tenantId)
  if (!modules.includes(moduleKey)) {
    throw new FeatureError('الميزة دي مش متاحة في باقتك الحالية', 403)
  }
}

export async function requireCapability(
  session: Pick<Session, 'tenantId' | 'role'>,
  capability: Capability,
) {
  if (session.role === 'SUPER_ADMIN') return
  // 🛡️ 2026-09-30 (قرار تجاري): المرتجع/الاستبدال بقى متاح لكل الباقات —
  // بنفترضه هنا مباشرة عشان القاعدة تشتغل فوراً حتى للـ tenants القدامى
  // اللي Plan بتاعهم في الداتابيز لسه ماعدلش (من غير ما تستنى re-seed).
  if ((capability as string) === 'returns_exchange') return
  const ctx = await getPlanContext(session.tenantId)
  if (!ctx.capabilities.includes(capability)) {
    throw new FeatureError(
      'الميزة دي متاحة في باقة أعلى (Pro) — يرجى ترقية الاشتراك',
      403,
    )
  }
}

/**
 * 🛡️ 2026-10-10: فحص حدود الباقة (maxUsers / maxProducts / maxBranches).
 *
 * قبل الإصلاح ده: الحدود كانت بتتحفظ في الـ DB من لوحة الأدمن بس مكان أي
 * فحص فعلي في الـ APIs — فصاحب الباقة كان يقدر يعمل فروع/مستخدمين/منتجات
 * بلا حدود مهما كانت الباقة بتقول.
 *
 * القواعد:
 *  - SUPER_ADMIN يتجاوز الفحص (زي requireModule/requireCapability).
 *  - الحد >= UNLIMITED_PLAN_LIMIT (999999) = "غير محدود" → مفيش فحص.
 *  - لو العدد الحالي >= الحد → FeatureError برسالة عربية واضحة (403).
 *
 * الاستخدام داخل POST handlers:
 *   try { await assertWithinPlanLimit(session, 'branches') }
 *   catch (e) { const fe = featureErrorResponse(e); if (fe) return NextResponse.json(fe.body, { status: fe.status }); throw e }
 */
export async function assertWithinPlanLimit(
  session: Pick<Session, 'tenantId' | 'role'>,
  kind: LimitKind,
): Promise<void> {
  // Super admin bypasses all plan gating.
  if (session.role === 'SUPER_ADMIN') return
  const ctx = await getPlanContext(session.tenantId)
  // 🛡️ FIX (tsc + سلوك مقصود): كان `ctx.limits[kind]` — مفاتيح الـ limits هي
  // maxUsers/maxProducts/maxBranches بينما kind هو users/products/branches،
  // فكانت النتيجة undefined دايمًا → حدود الباقة كانت بتتتجاهل بصمت.
  const limitKey: 'maxUsers' | 'maxProducts' | 'maxBranches' =
    kind === 'users' ? 'maxUsers' : kind === 'products' ? 'maxProducts' : 'maxBranches'
  const limit = ctx.limits[limitKey]
  if (!limit || limit >= UNLIMITED_PLAN_LIMIT) return

  // ⚡ العدّ بقى SQL خفيف بدل Prisma count (sql() هنا = مُعرّف آمن من whitelist ثابت)
  const sql = getSql()
  const tid = session.tenantId
  const table = kind === 'users' ? 'User' : kind === 'products' ? 'Product' : 'Branch'
  const res = await sql<{ cnt: number }[]>`
    SELECT COUNT(*)::int AS cnt FROM ${sql(table)} WHERE "tenantId" = ${tid}`
  const count = Number(res[0]?.cnt ?? 0)

  if (count >= limit) {
    throw new FeatureError(
      `وصلت للحد الأقصى لباقتك الحالية (${limit} ${LIMIT_KIND_LABEL[kind]} فقط) — قم بترقية الباقة لإضافة المزيد`,
      403,
    )
  }
}

/** Helper to convert FeatureError into a NextResponse-friendly shape. */
export function featureErrorResponse(e: unknown): { status: number; body: { error: string } } | null {
  if (e instanceof FeatureError) {
    return { status: e.status, body: { error: e.message } }
  }
  return null
}
