'use client'

import * as React from 'react'
import { FileText, Loader2, Pencil, Plus, RefreshCw, Trash2 } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { toast } from 'sonner'
import { api } from '@/lib/api'
import { formatCurrency, formatArabicDateTime } from '@/lib/format'
import { DateTimeCell } from './DateTimeCell'
import { printListReportHtml, openPrintWindow } from '@/lib/print'
import { useShopStore } from '@/lib/store'
import { useConfirm } from './ConfirmDialogProvider'
import { useDataRefresh } from '@/lib/offline/data-events'

interface Order {
  id: number
  customerName: string
  phone: string | null
  device: string
  issue: string
  cost: number
  status: string
  receivedAt: string
  deliveredAt: string | null
}

const STATUSES = ['مستلم', 'قيد العمل', 'مكتمل', 'مُسلَّم'] as const
type Status = (typeof STATUSES)[number]

function statusVariant(s: string): string {
  switch (s) {
    case 'مستلم':
      return 'bg-info-subtle text-info-subtle-foreground border-info-subtle'
    case 'قيد العمل':
      return 'bg-warning-subtle text-warning-subtle-foreground border-yellow-200'
    case 'مكتمل':
      return 'bg-info-subtle text-info-subtle-foreground border-info-subtle'
    case 'مُسلَّم':
      return 'bg-primary/15 text-primary border-primary/20'
    default:
      return 'bg-muted text-muted-foreground'
  }
}

export function MaintenanceView() {
  const confirm = useConfirm()
  const shopName = useShopStore((s) => s.shopName)
  const shopBranding = useShopStore((s) => s.branding)
  const [orders, setOrders] = React.useState<Order[]>([])
  const [loading, setLoading] = React.useState(true)
  const [dialogOpen, setDialogOpen] = React.useState(false)
  const [editing, setEditing] = React.useState<Order | null>(null)
  const [busy, setBusy] = React.useState<number | null>(null)

  const load = React.useCallback(async () => {
    setLoading(true)
    try {
      const data = await api<Order[]>('/api/maintenance')
      if (Array.isArray(data)) setOrders(data)
    } catch (e: any) {
      toast.error(e?.message || 'فشل تحميل أOrders الصيانة')
    } finally {
      setLoading(false)
    }
  }, [])

  React.useEffect(() => {
    load()
  }, [load])

  // 🛡️ ROOT FIX (2026-09-27): live refresh, see data-events.ts
  useDataRefresh(['maintenance'], load)

  const cycleStatus = async (o: Order) => {
    const idx = STATUSES.indexOf(o.status as Status)
    const next = STATUSES[(idx + 1) % STATUSES.length]
    setBusy(o.id)
    try {
      await api(`/api/maintenance/${o.id}`, {
        method: 'PUT',
        body: { status: next },
      })
      toast.success(`تم تغيير الحالة إلى: ${next}`)
      load()
    } catch (e: any) {
      toast.error(e?.message || 'فشل التغيير')
    } finally {
      setBusy(null)
    }
  }

  const remove = async (id: number) => {
    if (!(await confirm('حذف أمر الصيانة؟'))) return
    // ⚡ Optimistic
    const removed = orders.find((o) => o.id === id)
    setOrders((prev) => prev.filter((o) => o.id !== id))
    try {
      await api(`/api/maintenance/${id}`, { method: 'DELETE' })
      toast.success('تم الحذف')
      if (typeof navigator === 'undefined' || navigator.onLine) load()
    } catch (e: any) {
      if (e?.message?.includes('تم الحفظ') || e?.message?.includes('offline')) {
        toast.success('تم الحذف (offline — سيتم المزامنة لاحقاً)')
      } else {
        if (removed) setOrders((prev) => [removed, ...prev])
        toast.error(e?.message || 'فشل الحذف')
      }
    }
  }

  const exportPdf = () => {
    const totalCost = orders.reduce((s, o) => s + o.cost, 0)
    const pending = orders.filter((o) => o.status !== 'مُسلَّم').length

    const html = printListReportHtml(
      {
        title: 'الصيانة',
        subtitle: 'أوامر استلام الأجهزة وإصلاحها',
        columns: [
          { header: '#' },
          { header: 'العميل', align: 'right' },
          { header: 'الهاتف' },
          { header: 'الجهاز', align: 'right' },
          { header: 'العطل', align: 'right' },
          { header: 'الحالة' },
          { header: 'التكلفة' },
          { header: 'تاريخ الاستلام' },
          { header: 'تاريخ التسليم' },
        ],
        rows: orders.map((o, i) => [
          String(i + 1),
          o.customerName,
          o.phone ?? '—',
          o.device,
          o.issue || '—',
          o.status,
          formatCurrency(o.cost),
          <span dir="ltr" style={{ unicodeBidi: "isolate" }}>{formatArabicDateTime(o.receivedAt)}</span>,
          o.deliveredAt ? <span dir="ltr" style={{ unicodeBidi: "isolate" }}>{formatArabicDateTime(o.deliveredAt)}</span> : '—',
        ]),
        kpis: [
          { label: 'إجمالي أوامر الصيانة', value: String(orders.length) },
          { label: 'قيد التنفيذ / لم تُسلَّم', value: String(pending) },
          { label: 'إجمالي التكلفة', value: formatCurrency(totalCost), emphasize: true },
        ],
        emptyMessage: 'لا توجد أوامر صيانة',
      },
      {
        name: shopName,
        phone: shopBranding.phone || undefined,
        address: shopBranding.address || undefined,
        logo: shopBranding.logoPath || undefined,
      }
    )
    openPrintWindow(html, () => toast.error('الرجاء السماح بالنوافذ المنبثقة'))
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold">الصيانة</h1>
          <p className="text-sm text-muted-foreground">
            أوامر استلام الأجهاز وإصلاحها
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={exportPdf} disabled={loading}>
            <FileText className="size-4" />
            تصدير PDF
          </Button>
          <Button
            onClick={() => {
              setEditing(null)
              setDialogOpen(true)
            }}
          >
            <Plus className="size-4" />
            أوردر صيانة جديد
          </Button>
        </div>
      </div>

      <Card className="overflow-hidden py-0">
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : (
            <div className="hidden overflow-x-auto lg:block" dir="ltr">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10 text-center">#</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead className="w-36">الهاتف</TableHead>
                    <TableHead>الجهاز</TableHead>
                    <TableHead>العطل</TableHead>
                    <TableHead className="w-28 text-center">الحالة</TableHead>
                    <TableHead className="w-28 text-center">التكلفة</TableHead>
                    <TableHead className="w-52">تاريخ الاستلام</TableHead>
                    <TableHead className="w-52">تاريخ التسليم</TableHead>
                    <TableHead className="w-32 text-center">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={10}
                        className="py-8 text-center text-muted-foreground"
                      >
                        لا توجد أوامر صيانة
                      </TableCell>
                    </TableRow>
                  ) : (
                    orders.map((o, index) => (
                      <TableRow key={o.id}>
                        <TableCell className="text-center font-mono text-xs">{index + 1}</TableCell>
                        <TableCell className="font-medium">{o.customerName}</TableCell>
                        <TableCell className="text-muted-foreground text-xs">
                          {o.phone ?? '—'}
                        </TableCell>
                        <TableCell>{o.device}</TableCell>
                        <TableCell className="text-muted-foreground text-xs max-w-[220px] truncate" title={o.issue}>
                          {o.issue || '—'}
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge
                            variant="outline"
                            className={statusVariant(o.status)}
                          >
                            {o.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center tabular-nums">
                          {formatCurrency(o.cost)}
                        </TableCell>
                        <TableCell className="text-muted-foreground text-xs">
                          <DateTimeCell date={o.receivedAt} />
                        </TableCell>
                        <TableCell className="text-muted-foreground text-xs">
                          {o.deliveredAt ? <DateTimeCell date={o.deliveredAt} /> : '—'}
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex items-center justify-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8"
                              onClick={() => {
                                setEditing(o)
                                setDialogOpen(true)
                              }}
                              title="تعديل"
                            >
                              <Pencil className="size-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8"
                              onClick={() => cycleStatus(o)}
                              disabled={busy === o.id}
                              title="تغيير الحالة"
                            >
                              {busy === o.id ? (
                                <Loader2 className="size-4 animate-spin" />
                              ) : (
                                <RefreshCw className="size-4" />
                              )}
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 text-destructive hover:text-destructive"
                              onClick={() => remove(o.id)}
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}

          {/*
            نسخة الكروت — تظهر فقط على الشاشات الأصغر من lg.
            كل أمر صيانة بقى كارت مستقل يعرض البيانات الأساسية رأسيًا.
          */}
          {!loading && (
            <div className="grid grid-cols-1 gap-3 p-3 sm:grid-cols-2 lg:hidden">
              {orders.length === 0 ? (
                <p className="col-span-full py-8 text-center text-muted-foreground">
                  لا توجد أوامر صيانة
                </p>
              ) : (
                orders.map((o, index) => (
                  <div key={o.id} className="rounded-lg border bg-card p-3 hover:bg-muted/30 dark:hover:bg-muted/20">
                    {/* رأس الكارت: اسم العميل + شارة الحالة */}
                    <div className="flex items-start gap-3">
                      <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-primary-subtle text-base font-bold text-primary-subtle-foreground">
                        {o.customerName?.charAt(0) ?? '?'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="font-mono text-[10px] text-muted-foreground">
                            #{index + 1}
                          </span>
                          <p className="truncate font-medium leading-tight">
                            {o.customerName}
                          </p>
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {o.phone ?? 'بدون هاتف'}
                        </p>
                      </div>
                      <Badge variant="outline" className={statusVariant(o.status)}>
                        {o.status}
                      </Badge>
                    </div>

                    {/* الجهاز + العطل */}
                    <div className="mt-2 space-y-1 text-xs">
                      <div className="flex items-center gap-1.5">
                        <span className="text-muted-foreground">الجهاز:</span>
                        <span className="font-medium">{o.device}</span>
                      </div>
                      {o.issue && (
                        <div className="flex items-center gap-1.5">
                          <span className="text-muted-foreground">العطل:</span>
                          <span className="truncate font-medium" title={o.issue}>
                            {o.issue}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* شبكة البيانات: تكلفة/استلام/تسليم */}
                    <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border/60 pt-2 text-center">
                      <div>
                        <p className="text-[10px] text-muted-foreground">التكلفة</p>
                        <p className="text-xs font-semibold tabular-nums">
                          {formatCurrency(o.cost)}
                        </p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground">الاستلام</p>
                        <p className="text-[10px] text-muted-foreground">
                          <DateTimeCell date={o.receivedAt} />
                        </p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground">التسليم</p>
                        <p className="text-[10px] text-muted-foreground">
                          {o.deliveredAt ? <DateTimeCell date={o.deliveredAt} /> : '—'}
                        </p>
                      </div>
                    </div>

                    {/* إجراءات */}
                    <div className="mt-2 flex items-center justify-end gap-1 border-t border-border/60 pt-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8"
                        onClick={() => {
                          setEditing(o)
                          setDialogOpen(true)
                        }}
                        title="تعديل"
                      >
                        <Pencil className="size-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8"
                        onClick={() => cycleStatus(o)}
                        disabled={busy === o.id}
                        title="تغيير الحالة"
                      >
                        {busy === o.id ? (
                          <Loader2 className="size-4 animate-spin" />
                        ) : (
                          <RefreshCw className="size-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 text-destructive hover:text-destructive"
                        onClick={() => remove(o.id)}
                        title="حذف"
                      >
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <OrderDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        initial={editing}
        onSaved={() => load()}
      />
    </div>
  )
}

interface OrderDialogProps {
  open: boolean
  onOpenChange: (o: boolean) => void
  initial: Order | null
  onSaved: () => void
}

function OrderDialog({ open, onOpenChange, initial, onSaved }: OrderDialogProps) {
  const [customerName, setCustomerName] = React.useState('')
  const [phone, setPhone] = React.useState('')
  const [device, setDevice] = React.useState('')
  const [issue, setIssue] = React.useState('')
  const [cost, setCost] = React.useState('0')
  const [saving, setSaving] = React.useState(false)

  React.useEffect(() => {
    if (open) {
      setCustomerName(initial?.customerName ?? '')
      setPhone(initial?.phone ?? '')
      setDevice(initial?.device ?? '')
      setIssue(initial?.issue ?? '')
      setCost(initial ? String(initial.cost) : '0')
    }
  }, [open, initial])

  const submit = async () => {
    if (!customerName.trim()) {
      toast.error('اسم العميل مطلوب')
      return
    }
    if (!device.trim()) {
      toast.error('الجهاز مطلوب')
      return
    }
    setSaving(true)
    try {
      const payload = {
        customerName: customerName.trim(),
        phone: phone.trim() || null,
        device: device.trim(),
        issue: issue.trim(),
        cost: parseFloat(cost) || 0,
      }
      if (initial) {
        await api(`/api/maintenance/${initial.id}`, {
          method: 'PUT',
          body: payload,
        })
        toast.success('تم تحديث أمر الصيانة')
      } else {
        await api('/api/maintenance', { method: 'POST', body: payload })
        toast.success('تمت إضافة أمر الصيانة')
      }
      onSaved()
      onOpenChange(false)
    } catch (e: any) {
      toast.error(e?.message || 'فشل الحفظ')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>
            {initial ? 'تعديل أمر صيانة' : 'أمر صيانة جديد'}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="o-customer">
              اسم العميل <span className="text-destructive">*</span>
            </Label>
            <Input
              id="o-customer"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="o-phone">التليفون</Label>
            <Input
              id="o-phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="اختياري"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="o-device">
              الجهاز <span className="text-destructive">*</span>
            </Label>
            <Input
              id="o-device"
              value={device}
              onChange={(e) => setDevice(e.target.value)}
              placeholder="مثال: أيفون 13"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="o-issue">العطل / الملاحظات</Label>
            <Textarea
              id="o-issue"
              value={issue}
              onChange={(e) => setIssue(e.target.value)}
              rows={3}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="o-cost">التكلفة المتوقعة</Label>
            <Input
              id="o-cost"
              type="number"
              min={0}
              value={cost}
              onChange={(e) => setCost(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button onClick={submit} disabled={saving}>
            {saving && <Loader2 className="size-4 animate-spin" />}
            حفظ
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
