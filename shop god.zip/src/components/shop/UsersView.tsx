'use client'

/**
 * UsersView — «بطاقات الدخول» (2026)
 *
 * هوية الصفحة: كل مستخدم = بطاقة دخول (badge) معلّقة بشريط.
 *  - لون الشريط العلوي = مستوى الصلاحية (بنفسجي للمدير، رمادي فولاذي للموظف)
 *  - النقطة على الصورة = آخر مرة دخل فيها (مش «أونلاين» — هي تاريخ آخر تسجيل دخول)
 *  - الحساب الموقوف بيتختم «موقوف» وبيبهت
 * الهيرو بيجاوب على سؤال أمان واحد: «مين عنده صلاحية دخول دلوقتي؟»
 *
 * نفس بنية الصفحات التانية: rounded-3xl + tokens (bg-card / border / muted)
 * + dark mode + RTL (start/end) — من غير ما يشبه أي واحدة فيهم.
 * المنطق (API / refresh / PDF) زي ما هو بدون أي تغيير.
 */

import * as React from 'react'
import {
  AlertTriangle,
  Check,
  Clock,
  Eye,
  EyeOff,
  Info,
  FileText,
  KeyRound,
  LayoutGrid,
  List,
  Loader2,
  Lock,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  Store,
  TrendingUp,
  User,
  UserCog,
  UserX,
  Users,
  X,
} from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'
import { api } from '@/lib/api'
import { formatArabicDate, formatArabicDateTime } from '@/lib/format'
import { printListReportHtml, openPrintWindow } from '@/lib/print'
import { useShopStore } from '@/lib/store'
import { useDataRefresh } from '@/lib/offline/data-events'
import { useConfirm } from './ConfirmDialogProvider'
import { ALL_MODULES } from '@/lib/plan-constants'

/* ───────────────────────── الأنواع والمساعدات ───────────────────────── */

interface UserRow {
  id: string
  name: string
  email: string
  role: string
  active: boolean
  createdAt: string
  lastLoginAt?: string | null
  branchId?: number | null
  branch?: { name: string } | null
  permissions?: string | null
  canViewProfits?: boolean
}

type RoleFilter = 'all' | 'ADMIN' | 'EMPLOYEE'
type StatusFilter = 'all' | 'active' | 'off'
type ViewMode = 'badges' | 'list'
type Presence = 'today' | 'recent' | 'stale' | 'never'

const DAY = 86_400_000

const num = (n: number) => n.toLocaleString('en-US')

const isAdminRole = (r: string) => r === 'ADMIN' || r === 'SUPER_ADMIN'

// ألوان صور المستخدمين — ثابتة لكل اسم
const AVATAR_GRADS: [string, string][] = [
  ['#8b5cf6', '#d946ef'],
  ['#0ea5e9', '#6366f1'],
  ['#10b981', '#0d9488'],
  ['#f59e0b', '#ef4444'],
  ['#ec4899', '#f43f5e'],
  ['#14b8a6', '#0ea5e9'],
  ['#f97316', '#eab308'],
  ['#6366f1', '#8b5cf6'],
]
function gradOf(name: string): string {
  let h = 0
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0
  const [a, b] = AVATAR_GRADS[h % AVATAR_GRADS.length]
  return `linear-gradient(135deg, ${a}, ${b})`
}

const PRESENCE_LABEL: Record<Presence, string> = {
  today: 'دخل آخر 24 ساعة',
  recent: 'دخل خلال 30 يوم',
  stale: 'آخر دخول أقدم من 30 يوم',
  never: 'لسه ما دخلش',
}

function presenceOf(u: UserRow, now: number): Presence {
  if (!u.lastLoginAt) return 'never'
  const diff = now - new Date(u.lastLoginAt).getTime()
  if (diff < DAY) return 'today'
  if (diff < 30 * DAY) return 'recent'
  return 'stale'
}

const PRESENCE_DOT: Record<Presence, string> = {
  today: 'bg-emerald-500',
  recent: 'bg-amber-400',
  stale: 'bg-rose-400',
  never: 'border-2 border-muted-foreground/50 bg-card',
}

// جمع عربي بسيط: [مفرد, مثنى, جمع 3-10, تمييز 11+]
function plural(n: number, f: [string, string, string, string]) {
  if (n === 1) return f[0]
  if (n === 2) return f[1]
  if (n >= 3 && n <= 10) return `${n} ${f[2]}`
  return `${n} ${f[3]}`
}

function ago(iso: string, now: number): string {
  const diff = Math.max(0, now - new Date(iso).getTime())
  const m = Math.floor(diff / 60_000)
  if (m < 1) return 'دلوقتي'
  if (m < 60) return `من ${plural(m, ['دقيقة', 'دقيقتين', 'دقايق', 'دقيقة'])}`
  const h = Math.floor(m / 60)
  if (h < 24) return `من ${plural(h, ['ساعة', 'ساعتين', 'ساعات', 'ساعة'])}`
  const d = Math.floor(h / 24)
  if (d < 30) return `من ${plural(d, ['يوم', 'يومين', 'أيام', 'يوم'])}`
  const mo = Math.floor(d / 30)
  return `من ${plural(mo, ['شهر', 'شهرين', 'شهور', 'شهر'])}`
}

function strengthOf(pw: string): { score: number; label: string } {
  if (!pw) return { score: 0, label: '' }
  let s = 0
  if (pw.length >= 6) s++
  if (pw.length >= 10) s++
  if (/[A-Za-z]/.test(pw) && /\d/.test(pw)) s++
  if (/[^A-Za-z0-9]/.test(pw) || (/[a-z]/.test(pw) && /[A-Z]/.test(pw))) s++
  return { score: s, label: ['ضعيفة', 'مقبولة', 'جيدة', 'قوية'][Math.max(0, s - 1)] }
}

function genPassword(len = 10): string {
  const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  const buf = new Uint32Array(len)
  crypto.getRandomValues(buf)
  return Array.from(buf, (n) => chars[n % chars.length]).join('')
}

/* ───────────────────────── الصفحة ───────────────────────── */

export function UsersView() {
  const shopName = useShopStore((s) => s.shopName)
  const shopBranding = useShopStore((s) => s.branding)
  const confirm = useConfirm()

  const [users, setUsers] = React.useState<UserRow[]>([])
  const [loading, setLoading] = React.useState(true)
  const [dialogOpen, setDialogOpen] = React.useState(false)
  const [editing, setEditing] = React.useState<UserRow | null>(null)

  const [q, setQ] = React.useState('')
  const [role, setRole] = React.useState<RoleFilter>('all')
  const [status, setStatus] = React.useState<StatusFilter>('all')
  const [branch, setBranch] = React.useState<string>('all')
  const [view, setView] = React.useState<ViewMode>('badges')
  const [now, setNow] = React.useState(() => Date.now())

  const load = React.useCallback(async () => {
    setLoading(true)
    try {
      const data = await api<UserRow[]>('/api/users')
      setUsers(data)
      setNow(Date.now())
    } catch (e: any) {
      toast.error(e?.message || 'فشل تحميل المستخدمين')
    } finally {
      setLoading(false)
    }
  }, [])

  React.useEffect(() => {
    load()
  }, [load])

  // 🛡️ live refresh — see data-events.ts
  useDataRefresh(['users'], load)

  const openAdd = () => {
    setEditing(null)
    setDialogOpen(true)
  }
  const openEdit = (u: UserRow) => {
    setEditing(u)
    setDialogOpen(true)
  }

  const toggleActive = async (u: UserRow) => {
    if (u.active) {
      const ok = await confirm({
        title: `إيقاف حساب "${u.name}"؟`,
        description: 'مش هيقدر يسجّل دخول لحد ما ترجّع تفعّله تاني.',
        confirmText: 'إيقاف الحساب',
      })
      if (!ok) return
    }
    try {
      await api(`/api/users/${u.id}`, { method: 'PUT', body: { active: !u.active } })
      toast.success(u.active ? 'تم تعطيل المستخدم' : 'تم تفعيل المستخدم')
      load()
    } catch (e: any) {
      toast.error(e?.message || 'فشل التحديث')
    }
  }

  /* ───── إحصائيات الهيرو ───── */
  const stats = React.useMemo(() => {
    const act = users.filter((u) => u.active)
    const adminsOn = act.filter((u) => isAdminRole(u.role)).length
    const staffOn = act.length - adminsOn
    const off = users.length - act.length
    const today = act.filter((u) => presenceOf(u, now) === 'today').length
    const stale = act.filter((u) => presenceOf(u, now) === 'stale').length
    const never = act.filter((u) => presenceOf(u, now) === 'never').length
    return { total: users.length, adminsOn, staffOn, off, today, stale, never }
  }, [users, now])

  const branchOptions = React.useMemo(() => {
    const m = new Map<string, string>()
    users.forEach((u) => {
      if (u.branchId != null && u.branch?.name) m.set(String(u.branchId), u.branch.name)
    })
    return Array.from(m, ([id, name]) => ({ id, name }))
  }, [users])

  // الأدوات (بحث/فلاتر/عرض) بتظهر بس لما الفريق يكبر
  const showTools = users.length >= 6

  const filtered = React.useMemo(() => {
    if (users.length < 6) return users
    const t = q.trim().toLowerCase()
    return users.filter((u) => {
      if (role === 'ADMIN' && !isAdminRole(u.role)) return false
      if (role === 'EMPLOYEE' && isAdminRole(u.role)) return false
      if (status === 'active' && !u.active) return false
      if (status === 'off' && u.active) return false
      if (branch === 'none' && u.branchId != null) return false
      if (branch !== 'all' && branch !== 'none' && String(u.branchId) !== branch) return false
      if (t && !(u.name.toLowerCase().includes(t) || u.email.toLowerCase().includes(t))) return false
      return true
    })
  }, [users, q, role, status, branch])

  const hasFilter = q !== '' || role !== 'all' || status !== 'all' || branch !== 'all'
  const clearFilters = () => {
    setQ('')
    setRole('all')
    setStatus('all')
    setBranch('all')
  }

  const exportPdf = () => {
    const html = printListReportHtml(
      {
        title: 'المستخدمين',
        subtitle: 'إدارة حسابات المدراء والموظفين',
        columns: [
          { header: '#' },
          { header: 'الاسم', align: 'right' },
          { header: 'البريد الإلكتروني' },
          { header: 'الدور' },
          { header: 'الحالة' },
          { header: 'الفرع' },
          { header: 'تاريخ الإنشاء' },
          { header: 'آخر دخول' },
        ],
        rows: users.map((u, i) => [
          String(i + 1),
          u.name,
          u.email,
          isAdminRole(u.role) ? 'المدير' : 'الموظف',
          u.active ? 'نشط' : 'موقوف',
          u.branch?.name ?? 'كل الفروع',
          <span dir="ltr" style={{ unicodeBidi: 'isolate' }}>{formatArabicDateTime(u.createdAt)}</span>,
          u.lastLoginAt ? (
            <span dir="ltr" style={{ unicodeBidi: 'isolate' }}>{formatArabicDateTime(u.lastLoginAt)}</span>
          ) : (
            'لم يسجل دخول بعد'
          ),
        ]),
        kpis: [
          { label: 'إجمالي المستخدمين', value: String(users.length) },
          { label: 'المدراء', value: String(users.filter((u) => isAdminRole(u.role)).length) },
          { label: 'الحسابات النشطة', value: String(users.filter((u) => u.active).length), emphasize: true },
        ],
        emptyMessage: 'لا يوجد مستخدمين',
      },
      {
        name: shopName,
        phone: shopBranding.phone || undefined,
        address: shopBranding.address || undefined,
        logo: shopBranding.logoPath || undefined,
      }
    )
    openPrintWindow(html, () => toast.error('الرجاء السماح بالنوافذ المنبثقة'))
  }

  const noData = loading && users.length === 0

  return (
    <div className="space-y-5">
      {/* حركة واحدة بس: البطاقات بتتدلّى من الشريط أول ما الصفحة تفتح */}
      <style>{`
        @keyframes ub-hang {
          0%   { opacity: 0; transform: perspective(800px) rotateX(-65deg) translateY(-10px); }
          60%  { opacity: 1; transform: perspective(800px) rotateX(7deg); }
          100% { opacity: 1; transform: perspective(800px) rotateX(0); }
        }
        .ub-card { transform-origin: 50% 0; animation: ub-hang .55s cubic-bezier(.2,.8,.2,1) both; }
        .ub-off .ub-avatar { filter: grayscale(1); }
        @media (prefers-reduced-motion: reduce) { .ub-card { animation: none; } }
      `}</style>

      {/* ═════════ الهيرو — «من عنده صلاحية دخول؟» (صف واحد مضغوط) ═════════ */}
      <section className="relative overflow-hidden rounded-3xl border bg-card text-card-foreground shadow-sm">
        {/* شريط التعليق: خط مستقيم أعلى الكارت */}
        <span aria-hidden className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-l from-fuchsia-500 via-violet-600 to-violet-500" />
        <div
          aria-hidden
          className="pointer-events-none absolute -top-24 end-0 size-64 rounded-full bg-violet-500/10 blur-3xl dark:bg-violet-400/10"
        />

        <div className="relative flex flex-wrap items-center gap-x-8 gap-y-5 p-5 pt-6 sm:px-6">
          {/* الهوية + الرقم */}
          <div className="min-w-[230px]">
            <div className="flex items-center gap-2.5">
              <span className="flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-500 text-white shadow-md shadow-violet-500/25">
                <UserCog className="size-[18px]" />
              </span>
              <div>
                <h1 className="text-lg font-extrabold leading-tight">المستخدمين</h1>
                <p className="text-[11px] text-muted-foreground">حسابات الدخول وصلاحياتها</p>
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="bg-gradient-to-l from-violet-600 to-fuchsia-500 bg-clip-text text-5xl font-extrabold leading-none tracking-tight tabular-nums text-transparent dark:from-violet-300 dark:to-fuchsia-300">
                {noData ? '—' : num(stats.adminsOn + stats.staffOn)}
              </span>
              <span className="text-sm font-semibold text-muted-foreground">حساب يقدر يدخل دلوقتي</span>
            </div>
          </div>

          {/* التوزيع + التنبيهات */}
          <div className="min-w-[280px] flex-1">
            {!noData && users.length > 0 && (
              <>
                <div
                  className="flex h-2.5 w-full gap-0.5 overflow-hidden rounded-full bg-muted"
                  role="img"
                  aria-label="توزيع الحسابات حسب الصلاحية والحالة"
                >
                  {stats.adminsOn > 0 && (
                    <span style={{ flexGrow: stats.adminsOn }} className="bg-gradient-to-l from-violet-600 to-fuchsia-500" />
                  )}
                  {stats.staffOn > 0 && (
                    <span style={{ flexGrow: stats.staffOn }} className="bg-slate-500 dark:bg-slate-400" />
                  )}
                  {stats.off > 0 && (
                    <span
                      style={{
                        flexGrow: stats.off,
                        backgroundImage:
                          'repeating-linear-gradient(-45deg, rgba(244,63,94,.7) 0 4px, transparent 4px 8px)',
                      }}
                    />
                  )}
                </div>
                <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-[11px] text-muted-foreground">
                  <Legend swatch="bg-gradient-to-l from-violet-600 to-fuchsia-500" label="مدراء" value={stats.adminsOn} />
                  <Legend swatch="bg-slate-500 dark:bg-slate-400" label="موظفين" value={stats.staffOn} />
                  {stats.off > 0 && <Legend swatch="bg-rose-400/70" label="موقوفين" value={stats.off} />}
                </div>

                {/* تنبيهات الأمان: شريحة واحدة لو كله سليم */}
                <div className="mt-3 flex flex-wrap gap-2 text-xs font-semibold">
                  {stats.stale === 0 && stats.never === 0 ? (
                    <Chip tone="emerald" icon={ShieldCheck}>
                      {stats.today > 0
                        ? `كله متابَع — ${num(stats.today)} دخلوا آخر 24 ساعة`
                        : 'كله متابَع — مفيش حساب خامل'}
                    </Chip>
                  ) : (
                    <>
                      {stats.stale > 0 && (
                        <Chip tone="rose" icon={UserX}>
                          {num(stats.stale)} ما دخلوش من +30 يوم
                        </Chip>
                      )}
                      {stats.never > 0 && (
                        <Chip tone="amber" icon={KeyRound}>
                          {num(stats.never)} لسه ما دخلوش أبداً
                        </Chip>
                      )}
                      {stats.today > 0 && (
                        <Chip tone="emerald" icon={Clock}>
                          {num(stats.today)} دخلوا آخر 24 ساعة
                        </Chip>
                      )}
                    </>
                  )}
                </div>
              </>
            )}
          </div>

          {/* الإجراءات */}
          <div className="flex w-full flex-wrap items-center gap-2 lg:w-auto lg:flex-col lg:items-stretch">
            <Button
              size="lg"
              onClick={openAdd}
              className="bg-gradient-to-br from-violet-600 to-fuchsia-500 text-white shadow-sm hover:from-violet-500 hover:to-fuchsia-400 hover:shadow-md hover:shadow-violet-500/30"
            >
              <Plus className="size-4" />
              مستخدم جديد
            </Button>
            <Button variant="outline" onClick={exportPdf} disabled={loading || users.length === 0}>
              <FileText className="size-4" />
              تصدير PDF
            </Button>
          </div>
        </div>
      </section>

      {/* ═════════ شريط الفلاتر ═════════ */}
      {showTools && (
      <div className="space-y-3 rounded-2xl border bg-card p-3.5 shadow-sm sm:p-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute top-1/2 right-3.5 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث بالاسم أو الإيميل…"
              className="h-10 rounded-xl pr-10 pl-9"
            />
            {q && (
              <button
                type="button"
                onClick={() => setQ('')}
                aria-label="مسح البحث"
                className="absolute top-1/2 left-2.5 flex size-6 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground hover:bg-muted"
              >
                <X className="size-3.5" />
              </button>
            )}
          </div>

          <Seg
            value={role}
            onChange={(v) => setRole(v as RoleFilter)}
            options={[
              { v: 'all', l: 'الكل' },
              { v: 'ADMIN', l: 'مدراء' },
              { v: 'EMPLOYEE', l: 'موظفين' },
            ]}
            label="تصفية بالدور"
          />
          <Seg
            value={status}
            onChange={(v) => setStatus(v as StatusFilter)}
            options={[
              { v: 'all', l: 'كل الحالات' },
              { v: 'active', l: 'نشط' },
              { v: 'off', l: 'موقوف' },
            ]}
            label="تصفية بالحالة"
          />

          {branchOptions.length > 0 && (
            <Select dir="rtl" value={branch} onValueChange={setBranch}>
              <SelectTrigger className="h-10 w-[150px] rounded-xl">
                <Store className="size-4 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent dir="rtl">
                <SelectItem value="all">كل الفروع</SelectItem>
                <SelectItem value="none">من غير فرع (مدير)</SelectItem>
                {branchOptions.map((b) => (
                  <SelectItem key={b.id} value={b.id}>
                    {b.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}

          <div className="ms-auto flex rounded-xl border bg-muted/50 p-0.5" role="group" aria-label="طريقة العرض">
            {([
              ['badges', LayoutGrid, 'عرض البطاقات'],
              ['list', List, 'عرض القائمة'],
            ] as const).map(([v, Icon, title]) => (
              <button
                key={v}
                type="button"
                title={title}
                aria-label={title}
                aria-pressed={view === v}
                onClick={() => setView(v)}
                className={cn(
                  'flex size-8 items-center justify-center rounded-[10px] text-muted-foreground transition-colors',
                  view === v && 'bg-card text-foreground shadow-sm'
                )}
              >
                <Icon className="size-4" />
              </button>
            ))}
          </div>
        </div>

        {!loading && users.length > 0 && (
          <p className="flex items-center gap-2 text-[11px] text-muted-foreground">
            <span>
              عرض {num(filtered.length)} من {num(users.length)}
            </span>
            {hasFilter && (
              <button type="button" onClick={clearFilters} className="font-semibold text-violet-600 hover:underline dark:text-violet-400">
                مسح الفلاتر
              </button>
            )}
            <span
              className="ms-auto inline-flex cursor-help items-center gap-1"
              title={'النقطة على الصورة = آخر دخول:\n🟢 خلال 24 ساعة\n🟡 خلال 30 يوم\n🔴 أقدم من 30 يوم\n⚪ لسه ما دخلش'}
            >
              <Info className="size-3.5" />
              معنى النقط
            </span>
          </p>
        )}
      </div>
      )}

      {/* ═════════ المحتوى ═════════ */}
      {loading && users.length === 0 ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-[250px] rounded-2xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed bg-card/50 px-6 py-14 text-center">
          <span className="flex size-14 items-center justify-center rounded-2xl bg-violet-500/10 text-violet-600 dark:text-violet-400">
            <Users className="size-7" />
          </span>
          <div>
            <p className="font-bold">{users.length === 0 ? 'لسه مفيش مستخدمين' : 'مفيش نتايج بالفلاتر دي'}</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {users.length === 0
                ? 'أضف أول موظف وحدد فرعه وصلاحيته.'
                : 'جرّب كلمة بحث تانية أو امسح الفلاتر.'}
            </p>
          </div>
          {users.length === 0 ? (
            <Button onClick={openAdd}>
              <Plus className="size-4" />
              مستخدم جديد
            </Button>
          ) : (
            <Button variant="outline" onClick={clearFilters}>
              مسح الفلاتر
            </Button>
          )}
        </div>
      ) : view === 'badges' ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
          {filtered.map((u, i) => (
            <BadgeCard key={u.id} u={u} i={i} now={now} onEdit={openEdit} onToggle={toggleActive} />
          ))}
          {!hasFilter && (
            <button
              type="button"
              onClick={openAdd}
              className="group flex min-h-[200px] flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-violet-300/70 bg-violet-500/[0.03] p-6 text-violet-700 transition-colors hover:border-violet-500 hover:bg-violet-500/[0.07] dark:border-violet-400/30 dark:text-violet-300"
            >
              <span className="flex size-12 items-center justify-center rounded-2xl bg-violet-500/10 transition-transform group-hover:scale-105">
                <Plus className="size-6" />
              </span>
              <span className="text-sm font-bold">إضافة عضو للفريق</span>
              <span className="text-[11px] text-muted-foreground">بطاقة دخول جديدة بصلاحية وفرع</span>
            </button>
          )}
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border bg-card shadow-sm">
          <div className="hidden grid-cols-[minmax(0,2.2fr)_110px_minmax(0,1fr)_minmax(0,1fr)_130px] gap-3 border-b bg-muted/40 px-4 py-2.5 text-[11px] font-semibold text-muted-foreground lg:grid">
            <span>المستخدم</span>
            <span>الدور</span>
            <span>الفرع</span>
            <span>آخر دخول</span>
            <span className="text-end">الحالة</span>
          </div>
          <ul className="divide-y">
            {filtered.map((u) => (
              <ListRow key={u.id} u={u} now={now} onEdit={openEdit} onToggle={toggleActive} />
            ))}
          </ul>
        </div>
      )}

      <UserDialog open={dialogOpen} onOpenChange={setDialogOpen} initial={editing} onSaved={load} />
    </div>
  )
}

/* ───────────────────────── مكوّنات صغيرة ───────────────────────── */

function Legend({ swatch, label, value }: { swatch: string; label: string; value: number }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cn('size-2.5 rounded-full', swatch)} />
      {label}
      <b className="tabular-nums text-foreground">{num(value)}</b>
    </span>
  )
}

const CHIP_TONES = {
  rose: 'bg-rose-500/10 text-rose-700 dark:text-rose-300',
  amber: 'bg-amber-500/10 text-amber-700 dark:text-amber-300',
  emerald: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
} as const

function Chip({
  tone,
  icon: Icon,
  children,
}: {
  tone: keyof typeof CHIP_TONES
  icon: React.ElementType
  children: React.ReactNode
}) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 rounded-full px-3 py-1.5', CHIP_TONES[tone])}>
      <Icon className="size-3.5" />
      {children}
    </span>
  )
}

function Seg({
  value,
  onChange,
  options,
  label,
}: {
  value: string
  onChange: (v: string) => void
  options: { v: string; l: string }[]
  label: string
}) {
  return (
    <div className="flex rounded-xl border bg-muted/50 p-0.5" role="radiogroup" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.v}
          type="button"
          role="radio"
          aria-checked={value === o.v}
          onClick={() => onChange(o.v)}
          className={cn(
            'h-8 rounded-[10px] px-3 text-xs font-semibold text-muted-foreground transition-colors',
            value === o.v && 'bg-card text-foreground shadow-sm'
          )}
        >
          {o.l}
        </button>
      ))}
    </div>
  )
}

/** مفتاح تشغيل/إيقاف — dir=ltr جوه عشان الـ thumb ما ينعكسش في RTL */
function AccessSwitch({
  on,
  onClick,
  label,
}: {
  on: boolean
  onClick: () => void
  label: string
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onClick}
      dir="ltr"
      className={cn(
        'relative h-6 w-11 shrink-0 rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        on ? 'bg-emerald-500' : 'bg-muted-foreground/30'
      )}
    >
      <span
        className={cn(
          'absolute top-0.5 left-0.5 size-5 rounded-full bg-white shadow transition-transform',
          on && 'translate-x-5'
        )}
      />
    </button>
  )
}

function RolePill({ admin, onDark = false }: { admin: boolean; onDark?: boolean }) {
  const Icon = admin ? ShieldCheck : User
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold',
        onDark
          ? 'bg-white/15 text-white backdrop-blur'
          : admin
            ? 'bg-violet-500/10 text-violet-700 dark:text-violet-300'
            : 'bg-slate-500/10 text-slate-700 dark:text-slate-300'
      )}
    >
      <Icon className="size-3" />
      {admin ? 'مدير' : 'موظف'}
    </span>
  )
}

function Avatar({
  u,
  size,
  presence,
  className,
}: {
  u: Pick<UserRow, 'name'>
  size: string
  presence?: Presence
  className?: string
}) {
  return (
    <span className={cn('relative inline-flex shrink-0', className)}>
      <span
        className={cn(
          'ub-avatar flex items-center justify-center rounded-2xl font-extrabold text-white shadow-md',
          size
        )}
        style={{ background: gradOf(u.name || '?') }}
      >
        {u.name?.trim().charAt(0) || '?'}
      </span>
      {presence && (
        <span
          title={PRESENCE_LABEL[presence]}
          className={cn('absolute -bottom-1 -end-1 size-4 rounded-full ring-[3px] ring-card', PRESENCE_DOT[presence])}
        />
      )}
    </span>
  )
}

interface ItemProps {
  u: UserRow
  now: number
  onEdit: (u: UserRow) => void
  onToggle: (u: UserRow) => void
}

function lastLoginText(u: UserRow, now: number) {
  return u.lastLoginAt ? ago(u.lastLoginAt, now) : 'لسه ما دخلش'
}

/** بطاقة الدخول */
function BadgeCard({ u, i, now, onEdit, onToggle }: ItemProps & { i: number }) {
  const admin = isAdminRole(u.role)
  const presence = presenceOf(u, now)

  return (
    <article
      className={cn(
        'ub-card relative overflow-hidden rounded-2xl border bg-card shadow-sm transition-shadow hover:shadow-md',
        !u.active && 'ub-off'
      )}
      style={{ animationDelay: `${Math.min(i, 11) * 45}ms` }}
    >
      {/* رأس البطاقة: لون = مستوى الصلاحية */}
      <div
        className={cn(
          'relative h-[64px]',
          admin
            ? 'bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-500'
            : 'bg-gradient-to-br from-slate-800 to-slate-600 dark:from-slate-600 dark:to-slate-500',
          !u.active && 'opacity-60 saturate-50'
        )}
      >
        <span
          aria-hidden
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage: 'repeating-linear-gradient(-45deg, rgba(255,255,255,.35) 0 1px, transparent 1px 9px)',
            maskImage: 'linear-gradient(to bottom, black, transparent)',
            WebkitMaskImage: 'linear-gradient(to bottom, black, transparent)',
          }}
        />
        {/* فتحة الشريط */}
        <span
          aria-hidden
          className="absolute top-2.5 left-1/2 h-1.5 w-12 -translate-x-1/2 rounded-full bg-black/30 shadow-[inset_0_1px_2px_rgba(0,0,0,.35)]"
        />
      </div>

      <div className="px-4 pb-4">
        <div className="-mt-8 flex items-end gap-2.5">
          <Avatar u={u} size="size-[60px] text-2xl ring-4 ring-card" presence={presence} />
          <span className="mb-1">
            <RolePill admin={admin} />
          </span>
          {!u.active && (
            <span
              className="ms-auto mb-1 -rotate-6 rounded-md border-2 border-rose-500/70 px-2 py-0.5 text-xs font-extrabold text-rose-600 dark:text-rose-400"
              aria-label="الحساب موقوف"
            >
              موقوف
            </span>
          )}
        </div>

        <h3 className={cn('mt-2 truncate text-base font-extrabold leading-tight', !u.active && 'text-muted-foreground')}>
          {u.name}
        </h3>
        <p className="mt-0.5 truncate text-start text-xs text-muted-foreground" title={u.email}>
          <bdi dir="ltr">{u.email}</bdi>
        </p>

        <div className="mt-2.5 flex flex-wrap items-center gap-1.5 text-[11px]">
          <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-1 font-medium">
            <Store className="size-3 text-muted-foreground" />
            {u.branch?.name ?? 'كل الفروع'}
          </span>
        </div>

        <dl className="mt-2.5 grid grid-cols-2 gap-2 border-t border-dashed pt-2.5 text-[11px]">
          <div>
            <dt className="text-muted-foreground">آخر دخول</dt>
            <dd
              className="mt-0.5 font-semibold"
              title={u.lastLoginAt ? formatArabicDateTime(u.lastLoginAt) : undefined}
            >
              {lastLoginText(u, now)}
            </dd>
          </div>
          <div>
            <dt className="text-muted-foreground">انضم في</dt>
            <dd className="mt-0.5 font-semibold" title={formatArabicDateTime(u.createdAt)}>
              {formatArabicDate(u.createdAt)}
            </dd>
          </div>
        </dl>

        <div className="mt-3 flex items-center justify-between gap-2 rounded-xl bg-muted/50 px-3 py-1.5">
          <label className="flex cursor-pointer items-center gap-2 text-xs font-semibold">
            <AccessSwitch on={u.active} onClick={() => onToggle(u)} label={u.active ? 'إيقاف الحساب' : 'تفعيل الحساب'} />
            {u.active ? 'مسموح له بالدخول' : 'ممنوع من الدخول'}
          </label>
          <Button variant="ghost" size="icon-sm" onClick={() => onEdit(u)} title="تعديل" aria-label={`تعديل ${u.name}`}>
            <Pencil className="size-4" />
          </Button>
        </div>
      </div>
    </article>
  )
}

/** صف القائمة (للكثافة العالية) */
function ListRow({ u, now, onEdit, onToggle }: ItemProps) {
  const admin = isAdminRole(u.role)
  const presence = presenceOf(u, now)
  return (
    <li
      className={cn(
        'grid items-center gap-x-3 gap-y-2 px-4 py-3 lg:grid-cols-[minmax(0,2.2fr)_110px_minmax(0,1fr)_minmax(0,1fr)_130px]',
        !u.active && 'ub-off bg-muted/20'
      )}
    >
      <div className="flex min-w-0 items-center gap-3">
        <Avatar u={u} size="size-10 text-base !rounded-xl" presence={presence} />
        <div className="min-w-0">
          <p className={cn('truncate text-sm font-bold', !u.active && 'text-muted-foreground')}>{u.name}</p>
          <p className="truncate text-start text-xs text-muted-foreground">
            <bdi dir="ltr">{u.email}</bdi>
          </p>
        </div>
      </div>
      <div>
        <RolePill admin={admin} />
      </div>
      <p className="truncate text-xs text-muted-foreground">{u.branch?.name ?? 'كل الفروع'}</p>
      <p className="text-xs text-muted-foreground" title={u.lastLoginAt ? formatArabicDateTime(u.lastLoginAt) : undefined}>
        {lastLoginText(u, now)}
      </p>
      <div className="flex items-center justify-between gap-2 lg:justify-end">
        <AccessSwitch on={u.active} onClick={() => onToggle(u)} label={u.active ? 'إيقاف الحساب' : 'تفعيل الحساب'} />
        <Button variant="ghost" size="icon-sm" onClick={() => onEdit(u)} title="تعديل" aria-label={`تعديل ${u.name}`}>
          <Pencil className="size-4" />
        </Button>
      </div>
    </li>
  )
}

/* ───────────────────────── ديالوج الإضافة / التعديل ───────────────────────── */

interface Props {
  open: boolean
  onOpenChange: (o: boolean) => void
  initial: UserRow | null
  onSaved: () => void
}

function UserDialog({ open, onOpenChange, initial, onSaved }: Props) {
  const [name, setName] = React.useState('')
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [showPw, setShowPw] = React.useState(false)
  const [role, setRole] = React.useState<'ADMIN' | 'EMPLOYEE'>('EMPLOYEE')
  const [saving, setSaving] = React.useState(false)
  const [branchId, setBranchId] = React.useState<string>('')
  const [branches, setBranches] = React.useState<{ id: number; name: string }[]>([])
  // 🔑 RBAC
  const [useCustomPerms, setUseCustomPerms] = React.useState(false)
  const [selectedPerms, setSelectedPerms] = React.useState<string[]>([])
  const [canViewProfits, setCanViewProfits] = React.useState(false)

  React.useEffect(() => {
    if (open) {
      setName(initial?.name ?? '')
      setEmail(initial?.email ?? '')
      setPassword('')
      setShowPw(false)
      setRole(initial && isAdminRole(initial.role) ? 'ADMIN' : 'EMPLOYEE')
      setBranchId(initial?.branchId != null ? String(initial.branchId) : '')
      // RBAC init
      const parsedPerms = (() => {
        try { const v = JSON.parse(initial?.permissions ?? 'null'); return Array.isArray(v) ? v : null } catch { return null }
      })()
      setUseCustomPerms(!!parsedPerms && parsedPerms.length > 0)
      setSelectedPerms(parsedPerms ?? [])
      setCanViewProfits(Boolean(initial?.canViewProfits))
      fetch('/api/branches')
        .then((r) => (r.ok ? r.json() : []))
        .then(setBranches)
        .catch(() => setBranches([]))
    }
  }, [open, initial])

  const strength = strengthOf(password)
  const branchName = branches.find((b) => String(b.id) === branchId)?.name
  const unscoped = role === 'EMPLOYEE' && !branchId && branches.length > 0

  const submit = async () => {
    if (!name.trim()) return toast.error('الاسم مطلوب')
    if (!email.trim()) return toast.error('البريد الإلكتروني مطلوب')
    if (!initial && password.length < 6) return toast.error('كلمة المرور يجب أن تكون 6 أحرف على الأقل')
    if (initial && password && password.length < 6) return toast.error('كلمة المرور يجب أن تكون 6 أحرف على الأقل')
    setSaving(true)
    try {
      const body: any = {
        name: name.trim(),
        email: email.trim().toLowerCase(),
        role,
        branchId: branchId ? parseInt(branchId, 10) : null,
        permissions: role === 'ADMIN' ? null : (useCustomPerms ? selectedPerms : null),
        canViewProfits: role === 'ADMIN' ? true : canViewProfits,
      }
      if (initial) {
        if (password) body.password = password
        await api(`/api/users/${initial.id}`, { method: 'PUT', body })
        toast.success('تم تحديث المستخدم')
      } else {
        body.password = password
        await api('/api/users', { method: 'POST', body })
        toast.success('تمت إضافة المستخدم')
      }
      onSaved()
      onOpenChange(false)
    } catch (e: any) {
      toast.error(e?.message || 'فشل الحفظ')
    } finally {
      setSaving(false)
    }
  }

  const roles = [
    { v: 'EMPLOYEE' as const, icon: User, title: 'موظف', desc: 'بيشتغل على بيانات فرعه بس' },
    { v: 'ADMIN' as const, icon: ShieldCheck, title: 'مدير', desc: 'صلاحيات كاملة على كل الفروع' },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent showCloseButton={false} mobileSheet className="gap-0 overflow-hidden p-0 sm:max-w-[520px]">
        {/* معاينة البطاقة — بتتحدّث وإنت بتكتب */}
        <div
          className={cn(
            'relative px-6 pt-6 pb-7 text-white transition-colors duration-300',
            role === 'ADMIN'
              ? 'bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-500'
              : 'bg-gradient-to-br from-slate-800 to-slate-600 dark:from-slate-600 dark:to-slate-500'
          )}
        >
          <span
            aria-hidden
            className="absolute top-2.5 left-1/2 h-1.5 w-12 -translate-x-1/2 rounded-full bg-black/30 shadow-[inset_0_1px_2px_rgba(0,0,0,.35)]"
          />
          <DialogHeader className="text-start">
            <DialogTitle className="flex items-center gap-2 text-base text-white">
              <UserCog className="size-5" />
              {initial ? 'تعديل مستخدم' : 'مستخدم جديد'}
            </DialogTitle>
            <DialogDescription className="text-xs text-white/75">
              {initial ? 'غيّر البيانات أو الصلاحية — البطاقة بتتحدّث قدامك.' : 'اعمل بطاقة دخول جديدة للفريق.'}
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4 flex items-center gap-3 rounded-2xl bg-black/15 p-3 backdrop-blur-sm">
            <Avatar u={{ name: name || '?' }} size="size-14 text-2xl" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-extrabold">{name.trim() || 'اسم المستخدم'}</p>
              <p className="truncate text-start text-xs text-white/75">
                <bdi dir="ltr">{email.trim() || 'email@example.com'}</bdi>
              </p>
              <div className="mt-1.5 flex items-center gap-1.5">
                <RolePill admin={role === 'ADMIN'} onDark />
                <span
                  className={cn(
                    'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold',
                    unscoped ? 'bg-amber-400 text-amber-950' : 'bg-white/15'
                  )}
                >
                  {unscoped ? <AlertTriangle className="size-3" /> : <Store className="size-3" />}
                  {branchName ?? 'كل الفروع'}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4 p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="u-name">
                الاسم <span className="text-destructive">*</span>
              </Label>
              <Input id="u-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="off" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="u-email">
                البريد الإلكتروني <span className="text-destructive">*</span>
              </Label>
              <Input
                id="u-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                dir="ltr"
                autoComplete="off"
              />
            </div>
          </div>

          {/* الصلاحية */}
          <div className="space-y-1.5">
            <Label>الصلاحية</Label>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="الصلاحية">
              {roles.map((r) => {
                const sel = role === r.v
                return (
                  <button
                    key={r.v}
                    type="button"
                    role="radio"
                    aria-checked={sel}
                    onClick={() => setRole(r.v)}
                    className={cn(
                      'relative rounded-xl border p-3 text-start transition-colors',
                      sel
                        ? 'border-violet-500 bg-violet-500/5 ring-1 ring-violet-500'
                        : 'hover:bg-muted/50'
                    )}
                  >
                    <span className="flex items-center gap-2 text-sm font-bold">
                      <r.icon className={cn('size-4', sel ? 'text-violet-600 dark:text-violet-400' : 'text-muted-foreground')} />
                      {r.title}
                    </span>
                    <span className="mt-1 block text-[11px] leading-snug text-muted-foreground">{r.desc}</span>
                    {sel && (
                      <span className="absolute top-2 end-2 flex size-4 items-center justify-center rounded-full bg-violet-600 text-white">
                        <Check className="size-3" />
                      </span>
                    )}
                  </button>
                )
              })}
            </div>
          </div>

          {branches.length > 0 && (
            <div className="space-y-1.5">
              <Label>
                الفرع{' '}
                {role === 'EMPLOYEE' && (
                  <span className="text-xs font-normal text-muted-foreground">(الموظف هيشوف بيانات الفرع ده بس)</span>
                )}
              </Label>
              <Select dir="rtl" value={branchId || 'none'} onValueChange={(v) => setBranchId(v === 'none' ? '' : v)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر" />
                </SelectTrigger>
                <SelectContent dir="rtl">
                  <SelectItem value="none">كل الفروع (مدير)</SelectItem>
                  {branches.map((b) => (
                    <SelectItem key={b.id} value={String(b.id)}>
                      {b.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {unscoped && (
                <p className="flex items-start gap-2 rounded-xl bg-amber-500/10 px-3 py-2 text-xs text-amber-800 dark:text-amber-200" role="alert">
                  <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
                  الموظف من غير فرع مش هيتقيّد بفرع معيّن. اختار فرعه لو عايزه يشوف بياناته بس.
                </p>
              )}
            </div>
          )}

          {/* 🔑 صلاحيات الموظف */}
          {role === 'EMPLOYEE' && (
            <div className="space-y-3 rounded-2xl border border-dashed p-4">
              <div className="flex items-center gap-2">
                <Lock className="size-4 text-muted-foreground" />
                <span className="text-sm font-semibold">الصفحات المتاحة</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { v: false, label: 'كل الصفحات', sub: 'افتراضي — زي الباقة' },
                  { v: true, label: 'تحديد يدوي', sub: 'اختار الصفحات اللي يشوفها' },
                ].map((opt) => (
                  <button
                    key={String(opt.v)}
                    type="button"
                    onClick={() => { setUseCustomPerms(opt.v); if (!opt.v) setSelectedPerms([]) }}
                    className={`rounded-xl border p-3 text-start text-xs transition-colors ${
                      useCustomPerms === opt.v
                        ? 'border-violet-500 bg-violet-500/5 ring-1 ring-violet-500'
                        : 'hover:bg-muted/50'
                    }`}
                  >
                    <span className="block font-bold">{opt.label}</span>
                    <span className="text-muted-foreground">{opt.sub}</span>
                  </button>
                ))}
              </div>

              {useCustomPerms && (
                <div className="space-y-1.5">
                  <p className="text-xs text-muted-foreground">ضع علامة على الصفحات اللي هيقدر يدخلها:</p>
                  <div className="grid grid-cols-2 gap-1.5">
                    {ALL_MODULES.filter((m) => m !== 'guide').map((mod) => {
                      const labels: Record<string, string> = {
                        dashboard: 'لوحة المعلومات', pos: 'نقطة البيع', products: 'المنتجات',
                        sales: 'سجل المبيعات', maintenance: 'الصيانة', customers: 'العملاء',
                        suppliers: 'الموردين', purchases: 'المشتريات', inventory: 'المخزون',
                        finance: 'المعاملات المالية', expenses: 'المصروفات', cash: 'الخزنة',
                        reports: 'التقارير', settings: 'الإعدادات', users: 'المستخدمين',
                        branches: 'الفروع',
                      }
                      const checked = selectedPerms.includes(mod)
                      return (
                        <button
                          key={mod}
                          type="button"
                          onClick={() =>
                            setSelectedPerms((prev) =>
                              prev.includes(mod) ? prev.filter((x) => x !== mod) : [...prev, mod]
                            )
                          }
                          className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 text-xs transition-colors ${
                            checked
                              ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                              : 'hover:bg-muted/50 text-muted-foreground'
                          }`}
                        >
                          <span className={`flex size-4 shrink-0 items-center justify-center rounded border text-[10px] transition-colors ${
                            checked ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-muted-foreground/40'
                          }`}>
                            {checked && <Check className="size-3" />}
                          </span>
                          {labels[mod] ?? mod}
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* 🔒 رؤية الأرباح */}
              <div className="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 p-3">
                <TrendingUp className="mt-0.5 size-4 shrink-0 text-amber-600 dark:text-amber-400" />
                <div className="flex-1 space-y-1">
                  <p className="text-xs font-bold text-amber-800 dark:text-amber-300">رؤية الأرباح والتكاليف</p>
                  <p className="text-[11px] text-amber-700/80 dark:text-amber-400/80">
                    هل يقدر يشوف أرقام الأرباح والتكاليف في الداشبورد والتقارير؟
                  </p>
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      role="switch"
                      aria-checked={canViewProfits}
                      onClick={() => setCanViewProfits((v) => !v)}
                      className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors ${
                        canViewProfits ? 'bg-emerald-500' : 'bg-muted-foreground/30'
                      }`}
                    >
                      <span className={`pointer-events-none block size-4 rounded-full bg-white shadow-lg ring-0 transition-transform ${
                        canViewProfits ? 'translate-x-4' : 'translate-x-0'
                      }`} />
                    </button>
                    <span className="text-xs font-semibold">
                      {canViewProfits
                        ? <span className="text-emerald-600 dark:text-emerald-400">مسموح يشوف الأرباح</span>
                        : <span className="text-muted-foreground">محجوبة عنه (افتراضي)</span>
                      }
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* كلمة المرور */}
          <div className="space-y-1.5">
            <Label htmlFor="u-pass">
              كلمة المرور{' '}
              {initial ? (
                <span className="text-xs font-normal text-muted-foreground">(سيبها فاضية لو مش عايز تغيّرها)</span>
              ) : (
                <span className="text-destructive">*</span>
              )}
            </Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  id="u-pass"
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  dir="ltr"
                  autoComplete="new-password"
                  placeholder="••••••"
                  className="pe-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((s) => !s)}
                  aria-label={showPw ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                  className="absolute top-1/2 right-2.5 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPw ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setPassword(genPassword())
                  setShowPw(true)
                }}
                title="توليد كلمة مرور قوية"
              >
                <Sparkles className="size-4" />
                توليد
              </Button>
            </div>
            {password && (
              <div className="flex items-center gap-2" aria-live="polite">
                <div className="flex flex-1 gap-1">
                  {[1, 2, 3, 4].map((n) => (
                    <span
                      key={n}
                      className={cn(
                        'h-1 flex-1 rounded-full bg-muted transition-colors',
                        strength.score >= n &&
                          (strength.score <= 1
                            ? 'bg-rose-500'
                            : strength.score === 2
                              ? 'bg-amber-500'
                              : 'bg-emerald-500')
                      )}
                    />
                  ))}
                </div>
                <span className="text-[11px] text-muted-foreground">{strength.label}</span>
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="border-t bg-muted/30 px-6 py-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button
            onClick={submit}
            disabled={saving}
            className="bg-gradient-to-br from-violet-600 to-fuchsia-500 text-white hover:from-violet-500 hover:to-fuchsia-400"
          >
            {saving && <Loader2 className="size-4 animate-spin" />}
            {initial ? 'حفظ التعديلات' : 'إضافة المستخدم'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
