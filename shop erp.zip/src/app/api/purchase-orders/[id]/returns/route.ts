import { NextRequest, NextResponse } from 'next/server'
import { purchaseOrderInScope } from '@/lib/branch-scope-db'
import { withIdempotency } from '@/lib/idempotency'
import { db, withDb } from '@/lib/db'
import { requireAuth, authErrorResponse } from '@/lib/auth'
import { requireModule, featureErrorResponse } from '@/lib/features'
import { performPurchaseReturn, PurchaseReturnError } from '@/lib/purchase-return'
import { PURCHASE_POLICY } from '@/lib/stock-policy'

export const dynamic = 'force-dynamic'

// GET  → history of the returns made against this purchase order
// POST → return some (or all) of the items to the supplier.
//   body: { items: [{ itemId, quantity }], refund?: number,
//           refundMethod?: 'cash'|'vodafone_cash'|'instapay'|'fawry', note?: string }
//   refund = money the supplier really hands back. Omitted → the cash we paid on
//   this order (not yet refunded) is assumed to come back; the rest reduces the
//   supplier balance. The supplier balance ALWAYS drops by (returnValue - refund).

async function authorize() {
  const session = await requireAuth()
  await requireModule(session, 'purchases')
  return session
}

function fail(e: unknown) {
  const err = authErrorResponse(e)
  if (err) return NextResponse.json(err.body, { status: err.status })
  const fe = featureErrorResponse(e)
  if (fe) return NextResponse.json(fe.body, { status: fe.status })
  return null
}

async function __GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  let session
  try { session = await authorize() } catch (e) {
    const r = fail(e); if (r) return r; throw e
  }
  const oid = parseInt((await params).id, 10)
  if (isNaN(oid)) return NextResponse.json({ error: 'معرف غير صالح' }, { status: 400 })
  if (!(await purchaseOrderInScope(session.tenantId, oid, session.branchId))) {
    return NextResponse.json({ error: 'أمر الشراء غير موجود' }, { status: 404 })
  }

  const returns = await db.purchaseReturn.findMany({
    where: { purchaseOrderId: oid, tenantId: session.tenantId },
    orderBy: { id: 'desc' },
    include: { items: true },
  })
  return NextResponse.json(returns)
}

async function __POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  let session
  try { session = await authorize() } catch (e) {
    const r = fail(e); if (r) return r; throw e
  }
  const oid = parseInt((await params).id, 10)
  if (isNaN(oid)) return NextResponse.json({ error: 'معرف غير صالح' }, { status: 400 })
  if (!(await purchaseOrderInScope(session.tenantId, oid, session.branchId))) {
    return NextResponse.json({ error: 'أمر الشراء غير موجود' }, { status: 404 })
  }

  const body = await req.json().catch(() => null)
  if (!body || !Array.isArray(body.items) || body.items.length === 0) {
    return NextResponse.json({ error: 'اختر الأصناف المراد إرجاعها' }, { status: 400 })
  }

  // 🛡️ خ-11 (2026-11-02): سقف قيمة المرتجع للموظف — نفس سياسة أمر الشراء.
  // القيمة بتتحدد من تكلفة الأصناف المطلوبة (حد أعلى قبل خصم المرتجع السابق).
  if (session.role !== 'ADMIN' && session.role !== 'SUPER_ADMIN') {
    const itemIds = body.items
      .map((i: any) => Number(i?.itemId))
      .filter((n: number) => Number.isFinite(n))
    if (itemIds.length > 0) {
      const itemRows = await db.purchaseOrderItem.findMany({
        where: {
          id: { in: itemIds },
          purchaseOrder: { id: oid, tenantId: session.tenantId },
        },
        select: { id: true, cost: true },
      })
      const costById = new Map(itemRows.map((r) => [r.id, Number(r.cost) || 0]))
      let returnValue = 0
      for (const i of body.items) {
        const cost = costById.get(Number(i?.itemId)) ?? 0
        const qty = Math.max(0, Number(i?.quantity) || 0)
        returnValue += cost * qty
      }
      if (Math.round(returnValue * 100) / 100 > PURCHASE_POLICY.employeeMaxReturnValue) {
        return NextResponse.json(
          { error: `قيمة المرتجع ده (${Math.round(returnValue * 100) / 100} جنيه) أكبر من الحد المسموح للموظف (${PURCHASE_POLICY.employeeMaxReturnValue} جنيه) — محتاج المدير` },
          { status: 403 }
        )
      }
    }
  }

  try {
    const result = await db.$transaction((tx) =>
      performPurchaseReturn(tx, {
        tenantId: session.tenantId,
        userId: session.userId,
        orderId: oid,
        lines: body.items.map((i: any) => ({
          itemId: Number(i?.itemId),
          quantity: Number(i?.quantity),
        })),
        refund:
          body.refund === undefined || body.refund === null || body.refund === ''
            ? undefined
            : Number(body.refund),
        refundMethod: body.refundMethod ? String(body.refundMethod) : undefined,
        note: body.note ? String(body.note).trim() || null : null,
      })
    )
    return NextResponse.json({ ok: true, ...result }, { status: 201 })
  } catch (e) {
    if (e instanceof PurchaseReturnError) {
      return NextResponse.json({ error: e.message }, { status: e.status })
    }
    throw e
  }
}

export async function GET(...args: Parameters<typeof __GET>) {
  return withDb(() => __GET(...args))
}
export async function POST(...args: Parameters<typeof __POST>) {
  return withIdempotency(args[0] as NextRequest, () => withDb(() => __POST(...args)))
}
