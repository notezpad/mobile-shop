import { NextRequest, NextResponse } from 'next/server'
import { withIdempotency } from '@/lib/idempotency'
import { db, withDb } from '@/lib/db'
import { requireAdmin, authErrorResponse } from '@/lib/auth'
import { applyStocktakeDiff, computeStocktakeShrink, recordStocktakeShrinkLoss } from '@/lib/stocktake-stock'
import { STOCK_POLICY } from '@/lib/stock-policy'
import { withSql } from '@/lib/sql'
import { createNotification } from '@/lib/notifications'
export const dynamic = 'force-dynamic'

async function __POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  let s
  // 🛡️ اعتماد الجرد بيغيّر أرصدة المخزن — أدمن بس (زي إنشاء الجرد المعتمد)
  try { s = await requireAdmin() } catch (e) {
    const err = authErrorResponse(e); return NextResponse.json(err?.body,{status:err?.status})
  }
  const { id } = await ctx.params
  const sid = parseInt(id, 10)
  const st = await db.stocktake.findUnique({ where: { id: sid }, include: { items: true } })
  if (!st || st.tenantId !== s.tenantId) return NextResponse.json({ error: 'غير موجود' }, { status: 404 })
  if (st.status === 'committed') return NextResponse.json({ ok: true, alreadyCommitted: true })
  // 📉 عجز الجرد كخسارة (غير نقدية) — افتراضي، والمدير يقدر يلغيها (recordLoss:false)
  const body = await req.json().catch(() => null)
  const recordLoss = body?.recordLoss !== false
  const extraNote = body?.note ? String(body.note).trim() : (st.note ?? '')
  // 🛡️ ج-4 (2026-11-02): دمج الصفوف المكررة المحفوظة لنفس (productId, variantId)
  // قبل حساب العجز والتطبيق — نفس منطق دمج الإنشاء في POST. لو الصفوف اتطبّقت
  // كل واحدة بفرقها، الأساس النظامي بيتخصم مرتين والمخزون بيفسد.
  const mergedItems = new Map<string, { productId: number; variantId: number | null; counted: number; sys: number }>()
  for (const it of st.items) {
    if (it.productId == null) continue // صفوف منتجات محذوفة — بتتسكب
    const key = `${it.productId}:${it.variantId ?? '-'}`
    const prev = mergedItems.get(key)
    if (prev) {
      prev.counted = Math.round((prev.counted + it.countedQty) * 1000) / 1000
    } else {
      mergedItems.set(key, { productId: it.productId, variantId: it.variantId, counted: it.countedQty, sys: it.systemQty })
    }
  }
  const applyList = [...mergedItems.values()].map((m) => ({
    productId: m.productId,
    variantId: m.variantId,
    diff: Math.round((m.counted - m.sys) * 1000) / 1000,
  }))
  const shrink = await computeStocktakeShrink(db, s.tenantId, applyList)
  if (shrink.value >= STOCK_POLICY.stocktakeNoteThreshold && extraNote.trim().length < 3) {
    return NextResponse.json(
      { error: `عجز الجرد ${shrink.value} جنيه — اكتب ملاحظة توضّح السبب قبل الاعتماد` },
      { status: 400 },
    )
  }

  class AlreadyCommitted extends Error {}
  try {
    await db.$transaction(async (tx) => {
      // 🛡️ حجز ذري: ضغطتين/طلبين متزامنين ما يطبّقوش الجرد مرتين
      const claimed = await tx.stocktake.updateMany({
        where: { id: sid, tenantId: s.tenantId, status: { not: 'committed' } },
        data: { status: 'committed', committedAt: new Date() },
      })
      if (claimed.count !== 1) throw new AlreadyCommitted()
      for (const it of applyList) {
        // 🛡️ FIX (tsc): productId Int? — صفوف بقيت بعد حذف المنتج بتتسكب
        // (مفيش مخزون نعدّله لمنتج اتمسح).
        if (it.productId == null) continue
        await applyStocktakeDiff(
          tx,
          { tenantId: s.tenantId, userId: s.userId, branchId: st.branchId, stocktakeId: st.id, note: 'تسوية جرد' },
          { productId: it.productId, variantId: it.variantId, diff: it.diff },
        )
      }
      if (recordLoss) {
        await recordStocktakeShrinkLoss(tx, { tenantId: s.tenantId, userId: s.userId, branchId: st.branchId, stocktakeId: st.id }, shrink)
      }
    })
  } catch (e) {
    if (e instanceof AlreadyCommitted) return NextResponse.json({ ok: true, alreadyCommitted: true })
    throw e
  }

  // 🫥 (التحديث الحادي عشر): تنبيه عجز كبير في ورقة جرد أعمي — إشعار واحد
  // للمدير بعد الاعتماد الناجح (فوق نفس حد الملاحظة الإجبارية).
  if (st.mode === 'blind' && shrink.value >= STOCK_POLICY.stocktakeNoteThreshold) {
    try {
      await withSql(async (sql) => {
        await createNotification(sql, s.tenantId, {
          type: 'blind_shortage',
          title: 'عجز كبير في جرد أعمي',
          message: `ورقة الجرد الأعمي #${sid} اتعتمدت بعجز ${shrink.value} جنيه — راجع تقرير التغطية والأصناف الناقصة.`,
          link: '/inventory/stocktake',
        })
      })
    } catch {
      /* الإشعار مش حرج — الاعتماد تم بالفعل */
    }
  }

  return NextResponse.json({ ok: true })
}

export async function POST(...args: Parameters<typeof __POST>) {
  return withIdempotency(args[0] as NextRequest, () => withDb(() => __POST(...args)))
}
